// controllers/authController.js — UPDATED with OTP popup + all features
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Otp = require('../models/Otp');
const PharmacyProfile = require('../models/PharmacyProfile');
const DoctorProfile = require('../models/DoctorProfile');

const generateOtp = () => Math.floor(100000 + Math.random() * 900000).toString();

const signToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });

// ── POST /auth/send-otp ─────────────────────────────────────────────────────
exports.sendOtp = async (req, res, next) => {
  try {
    const { phone } = req.body;

    // Validate phone: exactly 10 digits
    if (!phone || !/^\d{10}$/.test(phone)) {
      return res.status(400).json({ success: false, message: 'Phone must be exactly 10 digits' });
    }

    const otp = generateOtp();
    await Otp.findOneAndDelete({ phone });
    await Otp.create({ phone, otp, expiresAt: new Date(Date.now() + 5 * 60 * 1000) });

    // ALWAYS return OTP in response (shown as popup in UI)
    // In production you can additionally send via SMS, but OTP is always in response
    if (process.env.NODE_ENV !== 'development' && process.env.TWILIO_ACCOUNT_SID) {
      try {
        const twilio = require('twilio')(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
        await twilio.messages.create({
          body: `Your MediQuick OTP is: ${otp}. Valid for 5 minutes.`,
          from: process.env.TWILIO_PHONE,
          to: `+91${phone}`,
        });
      } catch (err) {
        console.error('Twilio error (non-fatal):', err.message);
      }
    }

    // ALWAYS send OTP back so UI can display it as a popup
    res.json({
      success: true,
      message: 'OTP generated',
      otp, // Frontend displays this in a banner/popup on the login page
    });
  } catch (err) { next(err); }
};

// ── POST /auth/signup ───────────────────────────────────────────────────────
// Validates: name, phone (10 digits), email, role
exports.signup = async (req, res, next) => {
  try {
    const { name, phone, email, role } = req.body;

    if (!name?.trim()) return res.status(400).json({ success: false, message: 'Name is required' });
    if (!email?.trim()) return res.status(400).json({ success: false, message: 'Email is required' });
    if (!phone || !/^\d{10}$/.test(phone)) return res.status(400).json({ success: false, message: 'Phone must be exactly 10 digits' });
    if (!role || !['patient', 'pharmacy', 'doctor'].includes(role)) {
      return res.status(400).json({ success: false, message: 'Invalid role' });
    }

    const existing = await User.findOne({ phone });
    if (existing) return res.status(409).json({ success: false, message: 'Phone already registered. Please login.' });

    // Signup just registers — OTP verification happens at /auth/verify-otp
    res.json({ success: true, message: 'Proceed to OTP verification' });
  } catch (err) { next(err); }
};

// ── POST /auth/verify-otp ───────────────────────────────────────────────────
exports.verifyOtp = async (req, res, next) => {
  try {
    const { phone, otp, role, name, email } = req.body;

    if (!phone || !otp) return res.status(400).json({ success: false, message: 'Phone and OTP required' });
    if (!/^\d{10}$/.test(phone)) return res.status(400).json({ success: false, message: 'Phone must be exactly 10 digits' });

    const record = await Otp.findOne({ phone });
    if (!record) return res.status(400).json({ success: false, message: 'OTP not found or expired. Request a new one.' });
    if (record.expiresAt < new Date()) {
      await record.deleteOne();
      return res.status(400).json({ success: false, message: 'OTP expired. Request a new one.' });
    }
    if (record.otp !== otp) {
      record.attempts = (record.attempts || 0) + 1;
      if (record.attempts >= 5) {
        await record.deleteOne();
        return res.status(429).json({ success: false, message: 'Too many attempts. Request a new OTP.' });
      }
      await record.save();
      return res.status(400).json({ success: false, message: `Invalid OTP. ${5 - record.attempts} attempts left.` });
    }

    await record.deleteOne(); // OTP used — delete immediately

    // Find or create user
    let user = await User.findOne({ phone });
    if (!user) {
      if (!role || !name || !email) {
        return res.status(400).json({ success: false, message: 'New user: name, email, and role required' });
      }
      const isApproved = role === 'patient'; // Only patients auto-approve
      user = await User.create({ phone, name, email, role, isVerified: true, approved: isApproved });
    } else {
      user.isVerified = true;
      await user.save();
    }

    if (!user.approved && user.role !== 'patient') {
      return res.status(403).json({ success: false, message: 'Account pending admin approval.' });
    }

    const token = signToken(user._id);
    res.json({
      success: true,
      message: 'Authenticated',
      token,
      user: { id: user._id, name: user.name, phone: user.phone, email: user.email, role: user.role, approved: user.approved },
    });
  } catch (err) { next(err); }
};

// ── POST /auth/register/pharmacy ─────────────────────────────────────────────
exports.registerPharmacy = async (req, res, next) => {
  try {
    const { shopName, drugLicense, licenseOcrText, gstNumber, address, openTime, closeTime } = req.body;
    const user = req.user;

    if (user.role !== 'pharmacy') return res.status(400).json({ success: false, message: 'User role must be pharmacy' });

    const existing = await PharmacyProfile.findOne({ owner: user._id });
    if (existing) return res.status(409).json({ success: false, message: 'Pharmacy profile already exists' });

    // Basic OCR validation: license text must be present and have a license number pattern
    if (!licenseOcrText || licenseOcrText.length < 20) {
      return res.status(400).json({ success: false, message: 'Valid license text required for verification' });
    }

    const profile = await PharmacyProfile.create({
      owner: user._id, shopName, drugLicense, licenseOcrText, gstNumber, address, openTime, closeTime,
      status: 'pending', // Awaits admin approval
    });

    user.profileRef = profile._id;
    user.profileModel = 'PharmacyProfile';
    await user.save();

    res.status(201).json({ success: true, message: 'Registration submitted — pending admin approval', data: profile });
  } catch (err) { next(err); }
};

// ── POST /auth/register/doctor ────────────────────────────────────────────────
exports.registerDoctor = async (req, res, next) => {
  try {
    const { specialization, registrationNo, hospital, experience, consultationFee, qualifications } = req.body;
    const user = req.user;

    if (user.role !== 'doctor') return res.status(400).json({ success: false, message: 'User role must be doctor' });

    const existing = await DoctorProfile.findOne({ user: user._id });
    if (existing) return res.status(409).json({ success: false, message: 'Doctor profile already exists' });

    const profile = await DoctorProfile.create({
      user: user._id, specialization, registrationNo, hospital, experience, consultationFee, qualifications,
      status: 'pending',
    });

    user.profileRef = profile._id;
    user.profileModel = 'DoctorProfile';
    await user.save();

    res.status(201).json({ success: true, message: 'Registration submitted — pending admin approval', data: profile });
  } catch (err) { next(err); }
};

// ── GET /auth/me ──────────────────────────────────────────────────────────────
exports.getMe = async (req, res) => {
  const user = await User.findById(req.user._id).populate('profileRef');
  res.json({ success: true, data: user });
};
