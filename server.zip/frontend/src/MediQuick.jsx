import { useState, useEffect, useRef, useCallback } from "react";
import api from "./api";
// ─── Persistent Storage Helpers ─────────────────────────────────────────────
const db = {
  async get(key) {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : null;
  },

  async set(key, val) {
    localStorage.setItem(key, JSON.stringify(val));
    return true;
  },

  async del(key) {
    localStorage.removeItem(key);
    return true;
  }
};

// ─── Constants ───────────────────────────────────────────────────────────────
const ROLES = { patient: "👤 Patient", pharmacy: "🏪 Pharmacy", doctor: "🩺 Doctor", admin: "⚙️ Admin" };
const ADMIN_PHONE = "0000000000";

// ─── Utility ─────────────────────────────────────────────────────────────────
const genId = () => Math.random().toString(36).slice(2, 10);
const genOtp = () => Math.floor(100000 + Math.random() * 900000).toString();
const now = () => new Date().toISOString();
const fmtDate = d => new Date(d).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });

// ─── Styles ─────────────────────────────────────────────────────────────────
const S = {
  app: { fontFamily: "'DM Sans', system-ui, sans-serif", background: "#F0F4F8", minHeight: "100vh", display: "flex", flexDirection: "column", maxWidth: 430, margin: "0 auto", position: "relative", boxShadow: "0 0 40px rgba(0,0,0,.12)" },
  screen: { display: "flex", flexDirection: "column", height: "100vh", overflow: "hidden" },
  // Top bar
  topbar: { background: "#0B6E74", color: "#fff", padding: "14px 16px", display: "flex", alignItems: "center", gap: 12, flexShrink: 0 },
  topTitle: { fontWeight: 700, fontSize: 17, flex: 1 },
  topBack: { background: "none", border: "none", color: "#fff", fontSize: 22, cursor: "pointer", padding: "0 4px" },
  // Bottom nav
  bottomNav: { background: "#fff", borderTop: "1px solid #E2E8F0", display: "flex", flexShrink: 0 },
  navBtn: (active) => ({ flex: 1, border: "none", background: "none", padding: "10px 4px 8px", cursor: "pointer", fontSize: 10, color: active ? "#0B6E74" : "#94A3B8", fontWeight: active ? 600 : 400, display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }),
  navIcon: { fontSize: 20 },
  // Content
  scroll: { flex: 1, overflowY: "auto", WebkitOverflowScrolling: "touch" },
  pad: { padding: "16px" },
  // Cards
  card: { background: "#fff", borderRadius: 14, padding: 16, marginBottom: 12, border: "1px solid #E2E8F0" },
  cardTitle: { fontWeight: 600, fontSize: 15, color: "#0F172A", marginBottom: 4 },
  cardSub: { fontSize: 13, color: "#64748B" },
  // Inputs
  input: { width: "100%", padding: "11px 14px", border: "1.5px solid #E2E8F0", borderRadius: 10, fontSize: 15, fontFamily: "inherit", outline: "none", boxSizing: "border-box", background: "#fff" },
  label: { fontSize: 13, fontWeight: 500, color: "#1E293B", display: "block", marginBottom: 6 },
  field: { marginBottom: 14 },
  // Buttons
  btnPrimary: { background: "#0B6E74", color: "#fff", border: "none", borderRadius: 10, padding: "13px 20px", fontSize: 15, fontWeight: 600, cursor: "pointer", width: "100%", fontFamily: "inherit" },
  btnSecondary: { background: "#F1F5F9", color: "#0B6E74", border: "1px solid #E2E8F0", borderRadius: 10, padding: "10px 16px", fontSize: 14, fontWeight: 500, cursor: "pointer", fontFamily: "inherit" },
  btnDanger: { background: "#FEF2F2", color: "#EF4444", border: "1px solid #FECACA", borderRadius: 10, padding: "9px 14px", fontSize: 13, cursor: "pointer", fontFamily: "inherit" },
  btnSuccess: { background: "#ECFDF5", color: "#059669", border: "1px solid #6EE7B7", borderRadius: 10, padding: "9px 14px", fontSize: 13, cursor: "pointer", fontFamily: "inherit" },
  btnSm: { borderRadius: 8, padding: "7px 12px", fontSize: 12, fontWeight: 500, cursor: "pointer", fontFamily: "inherit", border: "none" },
  // Badge
  badge: (c) => ({ background: c === "green" ? "#ECFDF5" : c === "red" ? "#FEF2F2" : c === "amber" ? "#FFFBEB" : c === "blue" ? "#EFF6FF" : "#F1F5F9", color: c === "green" ? "#059669" : c === "red" ? "#EF4444" : c === "amber" ? "#D97706" : c === "blue" ? "#3B82F6" : "#64748B", borderRadius: 20, padding: "3px 10px", fontSize: 12, fontWeight: 600, display: "inline-block" }),
  // OTP boxes
  otpBox: { width: 46, height: 56, textAlign: "center", fontSize: 22, fontWeight: 700, border: "2px solid #E2E8F0", borderRadius: 10, outline: "none", fontFamily: "inherit", background: "#fff" },
  // Modal overlay (no position:fixed — use flow layout trick)
  modalWrap: { position: "absolute", inset: 0, background: "rgba(0,0,0,.5)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 50, padding: 16 },
  modal: { background: "#fff", borderRadius: 20, padding: 24, width: "100%", maxWidth: 370 },
  // Landing
  landing: { background: "linear-gradient(160deg,#064E53 0%,#0B6E74 60%,#14949C 100%)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: "100vh", padding: 24 },
  landingLogo: { width: 64, height: 64, background: "#fff", borderRadius: 18, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 34, marginBottom: 16 },
  landingTitle: { color: "#fff", fontSize: 30, fontWeight: 800, textAlign: "center", marginBottom: 6 },
  landingSub: { color: "rgba(255,255,255,.75)", fontSize: 15, textAlign: "center", marginBottom: 40 },
  roleCard: { background: "rgba(255,255,255,.13)", border: "1px solid rgba(255,255,255,.2)", borderRadius: 14, padding: "20px 24px", cursor: "pointer", textAlign: "center", color: "#fff", flex: 1, minWidth: 130 },
  // Stats
  statsGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 },
  statCard: { background: "#fff", borderRadius: 12, padding: "14px 16px", border: "1px solid #E2E8F0" },
  statNum: { fontSize: 24, fontWeight: 700, color: "#0B6E74" },
  statLabel: { fontSize: 12, color: "#64748B", marginTop: 2 },
  // Divider
  divider: { border: "none", borderTop: "1px solid #E2E8F0", margin: "12px 0" },
  // Error
  err: { background: "#FEF2F2", color: "#DC2626", borderRadius: 8, padding: "10px 14px", fontSize: 13, marginBottom: 12 },
  // Success
  success: { background: "#ECFDF5", color: "#059669", borderRadius: 8, padding: "10px 14px", fontSize: 13, marginBottom: 12 },
  // Pill tabs
  tabs: { display: "flex", gap: 8, marginBottom: 16, overflowX: "auto", paddingBottom: 2 },
  tab: (active) => ({ border: "none", borderRadius: 20, padding: "7px 16px", fontSize: 13, fontWeight: active ? 600 : 400, cursor: "pointer", whiteSpace: "nowrap", background: active ? "#0B6E74" : "#F1F5F9", color: active ? "#fff" : "#64748B" }),
  // Map placeholder
  mapBox: { background: "#E1F5F6", borderRadius: 12, padding: 20, textAlign: "center", color: "#0B6E74", fontSize: 14, marginBottom: 12 },
  // Prescription scan area
  scanBox: { border: "2px dashed #0B6E74", borderRadius: 12, padding: 24, textAlign: "center", cursor: "pointer", background: "#F0FDF9" },
  // Empty state
  empty: { textAlign: "center", padding: "32px 16px", color: "#94A3B8" },
  emptyIcon: { fontSize: 40, marginBottom: 8 },
  emptyText: { fontSize: 15, fontWeight: 500, color: "#64748B" },
  emptySub: { fontSize: 13, color: "#94A3B8", marginTop: 4 },
};

// ─── Root App ────────────────────────────────────────────────────────────────
export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [screen, setScreen] = useState("landing"); // landing | auth | app
  const [authRole, setAuthRole] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const saved = await db.get("currentUser");
      if (saved) { setCurrentUser(saved); setScreen("app"); }
      setLoading(false);
    })();
  }, []);

  const login = async (user) => {
    await db.set("currentUser", user);
    setCurrentUser(user);
    setScreen("app");
  };

  const logout = async () => {
    await db.del("currentUser");
    setCurrentUser(null);
    setScreen("landing");
  };

  if (loading) return <div style={{ ...S.landing, gap: 0 }}><div style={S.landingLogo}>💊</div><p style={{ color: "#fff" }}>Loading...</p></div>;

  if (screen === "landing") return (
    <Landing onSelect={(role) => { setAuthRole(role); setScreen("auth"); }} />
  );
  if (screen === "auth") return (
    <Auth role={authRole} onSuccess={login} onBack={() => setScreen("landing")} />
  );
  return <MainApp user={currentUser} onLogout={logout} />;
}

// ─── Landing Screen ───────────────────────────────────────────────────────────
function Landing({ onSelect }) {
  return (
    <div style={S.landing}>
      <div style={S.landingLogo}>💊</div>
      <h1 style={S.landingTitle}>MediQuick</h1>
      <p style={S.landingSub}>Healthcare at your fingertips</p>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 12, justifyContent: "center", width: "100%" }}>
        {Object.entries(ROLES).map(([role, label]) => (
          <div key={role} style={S.roleCard} onClick={() => onSelect(role)}>
            <div style={{ fontSize: 28, marginBottom: 8 }}>{label.split(" ")[0]}</div>
            <div style={{ fontWeight: 600, fontSize: 14 }}>{label.split(" ")[1]}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Auth Screen ──────────────────────────────────────────────────────────────
function Auth({ role, onSuccess, onBack }) {
  const [step, setStep] = useState("signup"); // signup | otp | licenseUpload
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [generatedOtp, setGeneratedOtp] = useState(null);
  const [otpBanner, setOtpBanner] = useState(null);
  const [license, setLicense] = useState("");
  const [licenseText, setLicenseText] = useState("");
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");
  const otpRefs = useRef([]);

  const handleSendOtp = async () => {
    setErr("");
    if (!/^\d{10}$/.test(phone)) { setErr("Phone must be exactly 10 digits."); return; }
    if (step === "signup" && !name.trim()) { setErr("Name is required."); return; }
    if (step === "signup" && !email.trim()) { setErr("Email is required."); return; }

    // Check if user exists for login
    const users = await db.get("users") || {};
    if (step === "signup" && users[phone] && users[phone].role === role) {
      setErr("Account exists. Please login instead.");
      return;
    }
    if (step === "login" && !users[phone]) {
      setErr("No account found. Please sign up.");
      return;
    }

    
const response = await api.post("/auth/send-otp", {
  phone
});

if (response.data.success) {
  setGeneratedOtp(response.data.otp);
  setOtpBanner(response.data.otp);
  setStep("otp");
}
    setMsg("OTP generated! Check the banner above.");
    setStep("otp");
    setTimeout(() => setOtpBanner(null), 60000);
  };

  const handleVerifyOtp = async () => {
    setErr("");
    const entered = otp.join("");
    if (entered.length !== 6) { setErr("Enter all 6 digits."); return; }
    const response = await api.post("/auth/verify-otp", {
  phone,
  otp: entered
});

if (response.data.success) {
  // login user
} else {
  setErr("Invalid OTP");
}

    // If pharmacy, require license
    if (role === "pharmacy" && step === "otp") {
      setStep("licenseUpload");
      return;
    }

    await completeAuth();
  };

  const handleLicenseSubmit = async () => {
    if (!licenseText.trim()) { setErr("Paste your license text for OCR verification."); return; }
    // Simulate OCR: check if text contains license-like content
    const hasLicenseNo = /\b[A-Z]{2,4}[\s\-]?\d{4,10}\b/.test(licenseText) || licenseText.length > 20;
    if (!hasLicenseNo) { setErr("License text doesn't appear valid. Include your full license number."); return; }
    setLicense(licenseText);
    await completeAuth(licenseText);
  };

  const completeAuth = async (licText = "") => {
    const users = await db.get("users") || {};
    let user;

    if (users[phone]) {
      user = users[phone];
    } else {
      user = {
        id: genId(), name, phone, email, role,
        createdAt: now(),
        approved: role === "patient" || role === "admin" ? true : false,
        pendingLicense: licText || null,
        licenseVerified: false,
      };
      // Special: admin phone auto-admin
      if (phone === ADMIN_PHONE) { user.role = "admin"; user.approved = true; }
      await api.post("/auth/register", {
      name,
      email,
      phone,
      role
});step

      // Add to pending approvals if pharmacy/doctor
      if (role === "pharmacy" || role === "doctor") {
        const pending = await db.get("pendingApprovals") || [];
        pending.push({ ...user, licenseText: licText });
        await db.set("pendingApprovals", pending);
      }
    }

    if (!user.approved && user.role !== "patient") {
      setErr("Your account is pending admin approval. Please wait.");
      return;
    }

    onSuccess(user);
  };

  const handleOtpKey = (i, e) => {
    const val = e.target.value.replace(/\D/g, "").slice(-1);
    const next = [...otp]; next[i] = val; setOtp(next);
    if (val && i < 5) otpRefs.current[i + 1]?.focus();
    if (!val && i > 0) otpRefs.current[i - 1]?.focus();
  };

  const isLogin = step === "login";

  return (
    <div style={{ ...S.screen, background: "#F0F4F8" }}>
      {otpBanner && (
        <div style={{ background: "#0B6E74", color: "#fff", padding: "12px 16px", textAlign: "center", fontSize: 15, fontWeight: 700, letterSpacing: 4, flexShrink: 0 }}>
          🔐 Your OTP: {otpBanner}
        </div>
      )}
      <div style={S.scroll}>
        <div style={{ padding: 24 }}>
          <button style={{ ...S.btnSecondary, width: "auto", marginBottom: 20 }} onClick={onBack}>← Back</button>
          <div style={{ background: "#fff", borderRadius: 20, padding: 24, border: "1px solid #E2E8F0" }}>
            <div style={{ fontSize: 28, textAlign: "center", marginBottom: 8 }}>{ROLES[role]?.split(" ")[0]}</div>
            <h2 style={{ textAlign: "center", fontSize: 22, fontWeight: 700, marginBottom: 4, color: "#0F172A" }}>
              {step === "otp" ? "Verify OTP" : step === "licenseUpload" ? "Upload License" : isLogin ? "Welcome back" : "Create account"}
            </h2>
            <p style={{ textAlign: "center", fontSize: 13, color: "#64748B", marginBottom: 20 }}>
              {ROLES[role]} · {step === "otp" ? "Enter the OTP from the green banner" : ""}
            </p>

            {err && <div style={S.err}>{err}</div>}
            {msg && !err && <div style={S.success}>{msg}</div>}

            {step === "licenseUpload" ? (
              <>
                <p style={{ fontSize: 13, color: "#64748B", marginBottom: 12 }}>For patient safety, paste your pharmacy drug license text below. Our OCR will verify it automatically.</p>
                <div style={S.field}>
                  <label style={S.label}>License Text (OCR)</label>
                  <textarea style={{ ...S.input, minHeight: 100, resize: "vertical" }} placeholder="Paste full license text e.g. DL-MH-2024-12345..." value={licenseText} onChange={e => setLicenseText(e.target.value)} />
                </div>
                <button style={S.btnPrimary} onClick={handleLicenseSubmit}>Verify & Submit</button>
                <p style={{ fontSize: 12, color: "#94A3B8", textAlign: "center", marginTop: 8 }}>Admin will review your license before activation.</p>
              </>
            ) : step === "otp" ? (
              <>
                <div style={{ display: "flex", gap: 8, justifyContent: "center", marginBottom: 20 }}>
                  {otp.map((d, i) => (
                    <input key={i} ref={el => otpRefs.current[i] = el} style={S.otpBox} maxLength={1} value={d} onChange={e => handleOtpKey(i, e)} inputMode="numeric" />
                  ))}
                </div>
                <button style={S.btnPrimary} onClick={handleVerifyOtp}>Verify OTP</button>
                <button style={{ ...S.btnSecondary, marginTop: 10, width: "100%" }} onClick={() => { setStep(isLogin ? "login" : "signup"); setOtp(["","","","","",""]); setOtpBanner(null); }}>Resend OTP</button>
              </>
            ) : (
              <>
                {!isLogin && (
                  <>
                    <div style={S.field}><label style={S.label}>Full Name</label><input style={S.input} placeholder="Your name" value={name} onChange={e => setName(e.target.value)} /></div>
                    <div style={S.field}><label style={S.label}>Email</label><input style={S.input} type="email" placeholder="you@email.com" value={email} onChange={e => setEmail(e.target.value)} /></div>
                  </>
                )}
                <div style={S.field}><label style={S.label}>Phone (10 digits)</label><input style={S.input} placeholder="9876543210" value={phone} onChange={e => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))} inputMode="numeric" /></div>
                <button style={S.btnPrimary} onClick={handleSendOtp}>Send OTP</button>
                <p style={{ textAlign: "center", fontSize: 13, color: "#64748B", marginTop: 14, cursor: "pointer" }} onClick={() => { setStep(isLogin ? "signup" : "login"); setErr(""); }}>
                  {isLogin ? "No account? Sign up" : "Already have account? Login"}
                </p>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Main App Shell ───────────────────────────────────────────────────────────
function MainApp({ user, onLogout }) {
  const [tab, setTab] = useState("home");

  const navItems = {
    patient: [
      { id: "home", icon: "🏠", label: "Home" },
      { id: "pharmacies", icon: "🏪", label: "Pharmacy" },
      { id: "prescription", icon: "📋", label: "Rx" },
      { id: "orders", icon: "📦", label: "Orders" },
      { id: "appointments", icon: "📅", label: "Appts" },
    ],
    pharmacy: [
      { id: "home", icon: "🏠", label: "Home" },
      { id: "inventory", icon: "💊", label: "Inventory" },
      { id: "incoming", icon: "📥", label: "Orders" },
      { id: "completed", icon: "✅", label: "Done" },
      { id: "profile", icon: "👤", label: "Profile" },
    ],
    doctor: [
      { id: "home", icon: "🏠", label: "Home" },
      { id: "appointments", icon: "📅", label: "Appts" },
      { id: "profile", icon: "👤", label: "Profile" },
    ],
    admin: [
      { id: "home", icon: "🏠", label: "Home" },
      { id: "approvals", icon: "✅", label: "Approvals" },
      { id: "pharmacies", icon: "🏪", label: "Pharmacies" },
      { id: "users", icon: "👥", label: "Users" },
    ],
  };

  const items = navItems[user.role] || navItems.patient;

  return (
    <div style={{ ...S.app, position: "relative" }}>
      <div style={S.screen}>
        <div style={S.topbar}>
          <div style={S.topTitle}>💊 MediQuick</div>
          <span style={{ fontSize: 13, color: "rgba(255,255,255,.8)" }}>{user.name}</span>
          <button style={{ ...S.topBack, fontSize: 18 }} onClick={onLogout} title="Logout">⏻</button>
        </div>

        <div style={S.scroll}>
          {renderPage(tab, user, setTab)}
        </div>

        <div style={S.bottomNav}>
          {items.map(it => (
            <button key={it.id} style={S.navBtn(tab === it.id)} onClick={() => setTab(it.id)}>
              <span style={S.navIcon}>{it.icon}</span>
              <span>{it.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function renderPage(tab, user, setTab) {
  if (user.role === "patient") {
    switch (tab) {
      case "home": return <PatientHome user={user} setTab={setTab} />;
      case "pharmacies": return <NearbyPharmacies />;
      case "prescription": return <PrescriptionPage user={user} />;
      case "orders": return <PatientOrders user={user} />;
      case "appointments": return <PatientAppointments user={user} />;
      default: return null;
    }
  }
  if (user.role === "pharmacy") {
    switch (tab) {
      case "home": return <PharmacyHome user={user} />;
      case "inventory": return <PharmacyInventory user={user} />;
      case "incoming": return <IncomingOrders user={user} />;
      case "completed": return <CompletedOrders user={user} />;
      case "profile": return <PharmacyProfile user={user} />;
      default: return null;
    }
  }
  if (user.role === "doctor") {
    switch (tab) {
      case "home": return <DoctorHome user={user} />;
      case "appointments": return <DoctorAppointments user={user} />;
      case "profile": return <DoctorProfilePage user={user} />;
      default: return null;
    }
  }
  if (user.role === "admin") {
    switch (tab) {
      case "home": return <AdminHome />;
      case "approvals": return <AdminApprovals />;
      case "pharmacies": return <AdminPharmacies />;
      case "users": return <AdminUsers />;
      default: return null;
    }
  }
  return null;
}

// ─── PATIENT PAGES ────────────────────────────────────────────────────────────
function PatientHome({ user, setTab }) {
  const [medicines, setMedicines] = useState([]);
  const [pharmacies, setPharmacies] = useState([]);

  useEffect(() => {
    (async () => {
      const inv = await db.get("inventory") || {};
      const all = Object.values(inv).flat();
      setMedicines(all.filter(m => !m.deleted).slice(0, 6));
      const ph = await db.get("approvedPharmacies") || [];
      setPharmacies(ph.slice(0, 3));
    })();
  }, []);

  return (
    <div style={S.pad}>
      <div style={{ background: "linear-gradient(135deg,#0B6E74,#14949C)", borderRadius: 16, padding: 20, color: "#fff", marginBottom: 16 }}>
        <p style={{ fontSize: 13, opacity: .8 }}>Good day,</p>
        <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 4 }}>{user.name} 👋</h2>
        <p style={{ fontSize: 13, opacity: .8 }}>Your health companion</p>
      </div>

      <div style={S.statsGrid}>
        <div style={S.statCard} onClick={() => setTab("orders")} className="tap">
          <div style={S.statNum}>📦</div>
          <div style={S.statLabel}>My Orders</div>
        </div>
        <div style={S.statCard} onClick={() => setTab("appointments")} className="tap">
          <div style={S.statNum}>📅</div>
          <div style={S.statLabel}>Appointments</div>
        </div>
      </div>

      <h3 style={{ fontWeight: 600, fontSize: 16, marginBottom: 10, color: "#0F172A" }}>Available Medicines</h3>
      {medicines.length === 0 ? (
        <div style={S.empty}><div style={S.emptyIcon}>💊</div><p style={S.emptyText}>No medicines yet</p></div>
      ) : (
        medicines.map(med => (
          <div key={med.id} style={{ ...S.card, display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ fontSize: 24 }}>💊</span>
            <div style={{ flex: 1 }}>
              <div style={S.cardTitle}>{med.name}</div>
              <div style={S.cardSub}>{med.category} · ₹{med.price}</div>
            </div>
            <div style={{ fontSize: 13, color: "#059669", fontWeight: 600 }}>In Stock</div>
          </div>
        ))
      )}

      <h3 style={{ fontWeight: 600, fontSize: 16, margin: "16px 0 10px", color: "#0F172A" }}>Nearby Pharmacies</h3>
      {pharmacies.length === 0 ? (
        <div style={S.empty}><div style={S.emptyIcon}>🏪</div><p style={S.emptyText}>No approved pharmacies</p></div>
      ) : (
        pharmacies.map(p => (
          <div key={p.id} style={S.card}>
            <div style={S.cardTitle}>🏪 {p.shopName || p.name}</div>
            <div style={S.cardSub}>{p.address || "Nearby"}</div>
          </div>
        ))
      )}
    </div>
  );
}

function NearbyPharmacies() {
  const [pharmacies, setPharmacies] = useState([]);
  const [query, setQuery] = useState("");

  useEffect(() => {
    (async () => {
      const ph = await db.get("approvedPharmacies") || [];
      setPharmacies(ph);
    })();
  }, []);

  const filtered = pharmacies.filter(p =>
    (p.shopName || p.name || "").toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div style={S.pad}>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 12, color: "#0F172A" }}>Nearby Pharmacies</h2>

      <div style={S.mapBox}>
        📍 Map View — Hyderabad, Telangana<br/>
        <span style={{ fontSize: 12, opacity: .7 }}>Showing pharmacies near you</span>
      </div>

      <input style={{ ...S.input, marginBottom: 12 }} placeholder="🔍 Search pharmacy..." value={query} onChange={e => setQuery(e.target.value)} />

      {filtered.length === 0 ? (
        <div style={S.empty}><div style={S.emptyIcon}>🏪</div><p style={S.emptyText}>No pharmacies found</p><p style={S.emptySub}>Check back after admin approves pharmacies</p></div>
      ) : (
        filtered.map(p => (
          <div key={p.id} style={S.card}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <div style={S.cardTitle}>🏪 {p.shopName || p.name}</div>
                <div style={S.cardSub}>{p.address || "Address not set"}</div>
                {p.openTime && <div style={{ fontSize: 12, color: "#059669", marginTop: 4 }}>⏰ {p.openTime} – {p.closeTime}</div>}
              </div>
              <span style={S.badge("green")}>Open</span>
            </div>
          </div>
        ))
      )}
    </div>
  );
}

function PrescriptionPage({ user }) {
  const [mode, setMode] = useState("upload"); // upload | typed | detected
  const [prescText, setPrescText] = useState("");
  const [detectedMeds, setDetectedMeds] = useState([]);
  const [selectedMeds, setSelectedMeds] = useState([]);
  const [pharmacyId, setPharmacyId] = useState("");
  const [pharmacies, setPharmacies] = useState([]);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const fileRef = useRef();

  useEffect(() => {
    (async () => {
      const ph = await db.get("approvedPharmacies") || [];
      setPharmacies(ph);
    })();
  }, []);

  const detectMedicines = () => {
    if (!prescText.trim()) { setErr("Enter or paste prescription text."); return; }
    // Simulate OCR/AI detection: look for capitalized words that could be drug names
    const knownMeds = ["Paracetamol", "Ibuprofen", "Amoxicillin", "Metformin", "Aspirin", "Omeprazole", "Atorvastatin", "Cetirizine"];
    const found = knownMeds.filter(m => prescText.toLowerCase().includes(m.toLowerCase()));
    // Also extract Proper Noun patterns
    const custom = [...prescText.matchAll(/\b([A-Z][a-z]{3,})\s*\d*(?:mg|ml|tablet|cap)?\b/g)].map(m => m[1]);
    const all = [...new Set([...found, ...custom])];
    setDetectedMeds(all);
    setMode("detected");
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      // Simulate OCR
      setPrescText("Paracetamol 500mg - 3 times daily\nIbuprofen 400mg - after food\nOmeprazole 20mg - morning");
      detectMedicines();
    };
    reader.readAsDataURL(file);
  };

  const placeOrder = async () => {
    if (!pharmacyId) { setErr("Select a pharmacy."); return; }
    if (selectedMeds.length === 0) { setErr("Select at least one medicine."); return; }
    setErr("");

    const orders = await db.get("orders") || [];
    const newOrder = {
      id: genId(), patientId: user.id, patientName: user.name,
      pharmacyId, medicines: selectedMeds, status: "pending",
      prescriptionText: prescText, createdAt: now(),
    };
    orders.push(newOrder);
    await db.set("orders", orders);

    // Notify pharmacy
    const pharmacyOrders = await db.get(`pharmacyOrders:${pharmacyId}`) || [];
    pharmacyOrders.push(newOrder);
    await db.set(`pharmacyOrders:${pharmacyId}`, pharmacyOrders);

    setMsg("Order placed successfully! Pharmacy will confirm soon.");
    setSelectedMeds([]); setPrescText(""); setMode("upload");
  };

  return (
    <div style={S.pad}>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 12, color: "#0F172A" }}>Prescription</h2>

      <div style={S.tabs}>
        <button style={S.tab(mode === "upload")} onClick={() => setMode("upload")}>Upload Rx</button>
        <button style={S.tab(mode === "typed")} onClick={() => setMode("typed")}>Type Rx</button>
        {detectedMeds.length > 0 && <button style={S.tab(mode === "detected")} onClick={() => setMode("detected")}>Review</button>}
      </div>

      {err && <div style={S.err}>{err}</div>}
      {msg && <div style={S.success}>{msg}</div>}

      {mode === "upload" && (
        <>
          <div style={S.scanBox} onClick={() => fileRef.current?.click()}>
            <div style={{ fontSize: 36, marginBottom: 8 }}>📸</div>
            <p style={{ fontWeight: 600, color: "#0B6E74" }}>Upload / Photograph Prescription</p>
            <p style={{ fontSize: 13, color: "#64748B", marginTop: 4 }}>Supports handwritten & printed Rx · AI OCR enabled</p>
          </div>
          <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={handleFileUpload} />
          <p style={{ textAlign: "center", color: "#94A3B8", fontSize: 13, marginTop: 8 }}>or type your prescription below</p>
          <button style={{ ...S.btnSecondary, marginTop: 8, width: "100%" }} onClick={() => setMode("typed")}>Type Manually</button>
        </>
      )}

      {mode === "typed" && (
        <>
          <div style={S.field}>
            <label style={S.label}>Prescription Text</label>
            <textarea style={{ ...S.input, minHeight: 120, resize: "vertical" }}
              placeholder="Paracetamol 500mg - 3 times daily&#10;Ibuprofen 400mg - twice daily"
              value={prescText} onChange={e => setPrescText(e.target.value)} />
          </div>
          <button style={S.btnPrimary} onClick={detectMedicines}>🔍 Detect Medicines</button>
        </>
      )}

      {mode === "detected" && (
        <>
          <div style={S.card}>
            <p style={{ fontWeight: 600, marginBottom: 8 }}>🧬 Detected Medicines</p>
            {detectedMeds.map(m => (
              <label key={m} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 0", borderBottom: "1px solid #F1F5F9", cursor: "pointer" }}>
                <input type="checkbox" checked={selectedMeds.includes(m)} onChange={e => {
                  setSelectedMeds(prev => e.target.checked ? [...prev, m] : prev.filter(x => x !== m));
                }} />
                <span style={{ fontSize: 14 }}>{m}</span>
              </label>
            ))}
          </div>

          <div style={S.field}>
            <label style={S.label}>Select Pharmacy</label>
            <select style={S.input} value={pharmacyId} onChange={e => setPharmacyId(e.target.value)}>
              <option value="">Choose pharmacy...</option>
              {pharmacies.map(p => <option key={p.id} value={p.id}>{p.shopName || p.name}</option>)}
            </select>
          </div>

          <button style={S.btnPrimary} onClick={placeOrder}>📦 Place Order</button>
        </>
      )}
    </div>
  );
}

function PatientOrders({ user }) {
  const [orders, setOrders] = useState([]);
  const [tab, setTab] = useState("active");

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    const all = await db.get("orders") || [];
    setOrders(all.filter(o => o.patientId === user.id));
  };

  const active = orders.filter(o => o.status !== "dispatched" && o.status !== "completed");
  const done = orders.filter(o => o.status === "dispatched" || o.status === "completed");

  const list = tab === "active" ? active : done;

  const statusColor = s => s === "dispatched" || s === "completed" ? "green" : s === "confirmed" ? "blue" : "amber";

  return (
    <div style={S.pad}>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 12, color: "#0F172A" }}>My Orders</h2>
      <div style={S.tabs}>
        <button style={S.tab(tab === "active")} onClick={() => setTab("active")}>Active ({active.length})</button>
        <button style={S.tab(tab === "done")} onClick={() => setTab("done")}>Completed ({done.length})</button>
      </div>

      {list.length === 0 ? (
        <div style={S.empty}>
          <div style={S.emptyIcon}>{tab === "active" ? "📦" : "✅"}</div>
          <p style={S.emptyText}>{tab === "active" ? "No active orders" : "No completed orders"}</p>
        </div>
      ) : list.map(o => (
        <div key={o.id} style={S.card}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
            <span style={{ fontWeight: 600, fontSize: 14 }}>Order #{o.id.slice(0, 6)}</span>
            <span style={S.badge(statusColor(o.status))}>{o.status}</span>
          </div>
          <div style={{ fontSize: 13, color: "#64748B" }}>{o.medicines?.join(", ")}</div>
          <div style={{ fontSize: 12, color: "#94A3B8", marginTop: 6 }}>{fmtDate(o.createdAt)}</div>
          {(o.status === "dispatched" || o.status === "completed") && (
            <div style={{ ...S.success, marginTop: 8, marginBottom: 0 }}>✅ Your order is on the way!</div>
          )}
        </div>
      ))}
    </div>
  );
}

function PatientAppointments({ user }) {
  const [appointments, setAppointments] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [doctorId, setDoctorId] = useState("");
  const [date, setDate] = useState("");
  const [reason, setReason] = useState("");
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => {
    (async () => {
      const appts = await db.get("appointments") || [];
      setAppointments(appts.filter(a => a.patientId === user.id));
      const users = await db.get("users") || {};
      setDoctors(Object.values(users).filter(u => u.role === "doctor" && u.approved));
    })();
  }, []);

  const book = async () => {
    setErr("");
    if (!doctorId || !date || !reason) { setErr("Fill all fields."); return; }
    const appt = { id: genId(), patientId: user.id, patientName: user.name, doctorId, date, reason, status: "booked", createdAt: now() };
    const all = await db.get("appointments") || [];
    all.push(appt);
    await db.set("appointments", all);
    setAppointments(prev => [...prev, appt]);
    setMsg("Appointment booked!"); setDoctorId(""); setDate(""); setReason("");
  };

  return (
    <div style={S.pad}>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 12, color: "#0F172A" }}>Appointments</h2>

      {err && <div style={S.err}>{err}</div>}
      {msg && <div style={S.success}>{msg}</div>}

      <div style={S.card}>
        <p style={{ fontWeight: 600, marginBottom: 12 }}>Book Appointment</p>
        <div style={S.field}>
          <label style={S.label}>Doctor</label>
          <select style={S.input} value={doctorId} onChange={e => setDoctorId(e.target.value)}>
            <option value="">Select doctor...</option>
            {doctors.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
        </div>
        <div style={S.field}>
          <label style={S.label}>Date & Time</label>
          <input style={S.input} type="datetime-local" value={date} onChange={e => setDate(e.target.value)} />
        </div>
        <div style={S.field}>
          <label style={S.label}>Reason</label>
          <input style={S.input} placeholder="e.g. Fever, back pain..." value={reason} onChange={e => setReason(e.target.value)} />
        </div>
        <button style={S.btnPrimary} onClick={book}>📅 Book Appointment</button>
      </div>

      <h3 style={{ fontWeight: 600, marginBottom: 10, fontSize: 15 }}>My Appointments</h3>
      {appointments.length === 0 ? (
        <div style={S.empty}><div style={S.emptyIcon}>📅</div><p style={S.emptyText}>No appointments yet</p></div>
      ) : appointments.map(a => (
        <div key={a.id} style={S.card}>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <span style={{ fontWeight: 600 }}>Dr. {doctors.find(d => d.id === a.doctorId)?.name || "Unknown"}</span>
            <span style={S.badge("blue")}>{a.status}</span>
          </div>
          <div style={{ fontSize: 13, color: "#64748B", marginTop: 4 }}>{a.reason}</div>
          <div style={{ fontSize: 12, color: "#94A3B8", marginTop: 4 }}>📅 {new Date(a.date).toLocaleString()}</div>
        </div>
      ))}
    </div>
  );
}

// ─── PHARMACY PAGES ───────────────────────────────────────────────────────────
function PharmacyHome({ user }) {
  const [stats, setStats] = useState({ orders: 0, medicines: 0 });

  useEffect(() => {
    (async () => {
      const orders = await db.get(`pharmacyOrders:${user.id}`) || [];
      const inv = await db.get(`inventory:${user.id}`) || [];
      setStats({ orders: orders.filter(o => o.status === "pending").length, medicines: inv.filter(m => !m.deleted).length });
    })();
  }, []);

  return (
    <div style={S.pad}>
      <div style={{ background: "linear-gradient(135deg,#0B6E74,#14949C)", borderRadius: 16, padding: 20, color: "#fff", marginBottom: 16 }}>
        <p style={{ fontSize: 13, opacity: .8 }}>Welcome back,</p>
        <h2 style={{ fontSize: 20, fontWeight: 700 }}>{user.name} 🏪</h2>
        <p style={{ fontSize: 13, opacity: .8 }}>Your pharmacy dashboard</p>
      </div>
      <div style={S.statsGrid}>
        <div style={S.statCard}>
          <div style={S.statNum}>{stats.orders}</div>
          <div style={S.statLabel}>Pending Orders</div>
        </div>
        <div style={S.statCard}>
          <div style={S.statNum}>{stats.medicines}</div>
          <div style={S.statLabel}>Medicines</div>
        </div>
      </div>
      {!user.approved && <div style={S.err}>⏳ Your account is pending admin approval. You can add inventory after approval.</div>}
    </div>
  );
}

function PharmacyInventory({ user }) {
  const [medicines, setMedicines] = useState([]);
  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [price, setPrice] = useState("");
  const [stock, setStock] = useState("");
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");

  useEffect(() => { loadMeds(); }, []);

  const loadMeds = async () => {
    const inv = await db.get(`inventory:${user.id}`) || [];
    setMedicines(inv.filter(m => !m.deleted));
  };

  const addMed = async () => {
    setErr("");
    if (!name || !price) { setErr("Name and price are required."); return; }
    const inv = await db.get(`inventory:${user.id}`) || [];
    const med = { id: genId(), name, category, price: parseFloat(price), stock: parseInt(stock) || 0, pharmacyId: user.id, pharmacyName: user.name, createdAt: now(), deleted: false };
    inv.push(med);
    await db.set(`inventory:${user.id}`, inv);

    // Also update global inventory mirror
    const globalInv = await db.get("inventory") || {};
    if (!globalInv[user.id]) globalInv[user.id] = [];
    globalInv[user.id].push(med);
    await db.set("inventory", globalInv);

    setMsg("Medicine added!"); setName(""); setCategory(""); setPrice(""); setStock("");
    loadMeds();
  };

  const deleteMed = async (id) => {
    const inv = await db.get(`inventory:${user.id}`) || [];
    const updated = inv.map(m => m.id === id ? { ...m, deleted: true } : m);
    await db.set(`inventory:${user.id}`, updated);

    // Update global
    const globalInv = await db.get("inventory") || {};
    if (globalInv[user.id]) {
      globalInv[user.id] = globalInv[user.id].map(m => m.id === id ? { ...m, deleted: true } : m);
      await db.set("inventory", globalInv);
    }
    setMsg("Medicine removed."); loadMeds();
  };

  return (
    <div style={S.pad}>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 12, color: "#0F172A" }}>Medicine Inventory</h2>
      {err && <div style={S.err}>{err}</div>}
      {msg && <div style={S.success}>{msg}</div>}

      <div style={S.card}>
        <p style={{ fontWeight: 600, marginBottom: 12 }}>➕ Add Medicine</p>
        <div style={S.field}><label style={S.label}>Medicine Name</label><input style={S.input} placeholder="e.g. Paracetamol" value={name} onChange={e => setName(e.target.value)} /></div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <div style={S.field}><label style={S.label}>Category</label><input style={S.input} placeholder="e.g. Tablet" value={category} onChange={e => setCategory(e.target.value)} /></div>
          <div style={S.field}><label style={S.label}>Price (₹)</label><input style={S.input} type="number" placeholder="99" value={price} onChange={e => setPrice(e.target.value)} /></div>
        </div>
        <div style={S.field}><label style={S.label}>Stock Qty</label><input style={S.input} type="number" placeholder="100" value={stock} onChange={e => setStock(e.target.value)} /></div>
        <button style={S.btnPrimary} onClick={addMed}>Add Medicine</button>
      </div>

      <h3 style={{ fontWeight: 600, fontSize: 15, marginBottom: 10 }}>Current Stock ({medicines.length})</h3>
      {medicines.length === 0 ? (
        <div style={S.empty}><div style={S.emptyIcon}>💊</div><p style={S.emptyText}>No medicines added</p></div>
      ) : medicines.map(m => (
        <div key={m.id} style={{ ...S.card, display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ fontSize: 22 }}>💊</span>
          <div style={{ flex: 1 }}>
            <div style={S.cardTitle}>{m.name}</div>
            <div style={S.cardSub}>{m.category} · ₹{m.price} · {m.stock} units</div>
          </div>
          <button style={S.btnDanger} onClick={() => deleteMed(m.id)}>🗑</button>
        </div>
      ))}
    </div>
  );
}

function IncomingOrders({ user }) {
  const [orders, setOrders] = useState([]);

  useEffect(() => { loadOrders(); }, []);

  const loadOrders = async () => {
    const all = await db.get(`pharmacyOrders:${user.id}`) || [];
    setOrders(all.filter(o => o.status === "pending" || o.status === "confirmed"));
  };

  const dispatch = async (orderId) => {
    const phOrders = await db.get(`pharmacyOrders:${user.id}`) || [];
    const updated = phOrders.map(o => o.id === orderId ? { ...o, status: "dispatched", dispatchedAt: now() } : o);
    await db.set(`pharmacyOrders:${user.id}`, updated);

    // Update global orders
    const allOrders = await db.get("orders") || [];
    const updatedAll = allOrders.map(o => o.id === orderId ? { ...o, status: "dispatched", dispatchedAt: now() } : o);
    await db.set("orders", updatedAll);

    // Save to completed
    const completed = await db.get(`completedOrders:${user.id}`) || [];
    const dispatched = updated.find(o => o.id === orderId);
    if (dispatched) completed.push(dispatched);
    await db.set(`completedOrders:${user.id}`, completed);

    loadOrders();
  };

  return (
    <div style={S.pad}>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 12, color: "#0F172A" }}>Incoming Orders</h2>
      {orders.length === 0 ? (
        <div style={S.empty}><div style={S.emptyIcon}>📥</div><p style={S.emptyText}>No pending orders</p></div>
      ) : orders.map(o => (
        <div key={o.id} style={S.card}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
            <span style={{ fontWeight: 600 }}>Order #{o.id.slice(0, 6)}</span>
            <span style={S.badge("amber")}>{o.status}</span>
          </div>
          <div style={{ fontSize: 13, color: "#0F172A", marginBottom: 4 }}>👤 {o.patientName}</div>
          <div style={{ fontSize: 13, color: "#64748B" }}>💊 {o.medicines?.join(", ")}</div>
          {o.prescriptionText && <div style={{ fontSize: 12, color: "#94A3B8", marginTop: 4, fontStyle: "italic" }}>Rx: {o.prescriptionText.slice(0, 80)}...</div>}
          <div style={{ fontSize: 12, color: "#94A3B8", marginTop: 4 }}>{fmtDate(o.createdAt)}</div>
          <button style={{ ...S.btnPrimary, marginTop: 10 }} onClick={() => dispatch(o.id)}>🚚 Mark Dispatched</button>
        </div>
      ))}
    </div>
  );
}

function CompletedOrders({ user }) {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    (async () => {
      const done = await db.get(`completedOrders:${user.id}`) || [];
      setOrders(done.reverse());
    })();
  }, []);

  return (
    <div style={S.pad}>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 12, color: "#0F172A" }}>Completed Orders</h2>
      {orders.length === 0 ? (
        <div style={S.empty}><div style={S.emptyIcon}>✅</div><p style={S.emptyText}>No completed orders yet</p></div>
      ) : orders.map(o => (
        <div key={o.id} style={S.card}>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <span style={{ fontWeight: 600 }}>#{o.id.slice(0, 6)}</span>
            <span style={S.badge("green")}>Dispatched</span>
          </div>
          <div style={{ fontSize: 13, color: "#64748B", marginTop: 4 }}>👤 {o.patientName} · {o.medicines?.join(", ")}</div>
          <div style={{ fontSize: 12, color: "#94A3B8", marginTop: 4 }}>🚚 {o.dispatchedAt ? fmtDate(o.dispatchedAt) : "—"}</div>
        </div>
      ))}
    </div>
  );
}

function PharmacyProfile({ user }) {
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    (async () => {
      const pending = await db.get("pendingApprovals") || [];
      const found = pending.find(p => p.id === user.id);
      setProfile(found);
    })();
  }, []);

  return (
    <div style={S.pad}>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 12, color: "#0F172A" }}>My Profile</h2>
      <div style={S.card}>
        <div style={{ fontWeight: 600, fontSize: 16, marginBottom: 4 }}>{user.name}</div>
        <div style={{ color: "#64748B", fontSize: 14 }}>📞 {user.phone}</div>
        <div style={{ color: "#64748B", fontSize: 14 }}>📧 {user.email}</div>
        <hr style={S.divider} />
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontSize: 14 }}>Account Status</span>
          <span style={S.badge(user.approved ? "green" : "amber")}>{user.approved ? "Approved" : "Pending"}</span>
        </div>
        {profile?.licenseText && (
          <div style={{ marginTop: 10 }}>
            <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 4 }}>License Submitted</div>
            <div style={{ fontSize: 12, color: "#64748B", background: "#F8FAFC", borderRadius: 8, padding: 10 }}>{profile.licenseText.slice(0, 120)}...</div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── DOCTOR PAGES ─────────────────────────────────────────────────────────────
function DoctorHome({ user }) {
  const [appts, setAppts] = useState([]);

  useEffect(() => {
    (async () => {
      const all = await db.get("appointments") || [];
      setAppts(all.filter(a => a.doctorId === user.id));
    })();
  }, []);

  return (
    <div style={S.pad}>
      <div style={{ background: "linear-gradient(135deg,#0B6E74,#14949C)", borderRadius: 16, padding: 20, color: "#fff", marginBottom: 16 }}>
        <p style={{ fontSize: 13, opacity: .8 }}>Doctor Portal</p>
        <h2 style={{ fontSize: 20, fontWeight: 700 }}>Dr. {user.name} 🩺</h2>
      </div>
      <div style={S.statsGrid}>
        <div style={S.statCard}><div style={S.statNum}>{appts.length}</div><div style={S.statLabel}>Appointments</div></div>
        <div style={S.statCard}><div style={S.statNum}>{appts.filter(a => a.status === "booked").length}</div><div style={S.statLabel}>Upcoming</div></div>
      </div>
      <h3 style={{ fontWeight: 600, fontSize: 15, marginBottom: 10 }}>Recent Appointments</h3>
      {appts.slice(0, 5).map(a => (
        <div key={a.id} style={S.card}>
          <div style={S.cardTitle}>👤 {a.patientName}</div>
          <div style={S.cardSub}>{a.reason} · {new Date(a.date).toLocaleString()}</div>
        </div>
      ))}
    </div>
  );
}

function DoctorAppointments({ user }) {
  const [appts, setAppts] = useState([]);

  useEffect(() => {
    (async () => {
      const all = await db.get("appointments") || [];
      setAppts(all.filter(a => a.doctorId === user.id));
    })();
  }, []);

  const updateStatus = async (id, status) => {
    const all = await db.get("appointments") || [];
    const updated = all.map(a => a.id === id ? { ...a, status } : a);
    await db.set("appointments", updated);
    setAppts(updated.filter(a => a.doctorId === user.id));
  };

  return (
    <div style={S.pad}>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 12 }}>My Appointments</h2>
      {appts.length === 0 ? (
        <div style={S.empty}><div style={S.emptyIcon}>📅</div><p style={S.emptyText}>No appointments yet</p></div>
      ) : appts.map(a => (
        <div key={a.id} style={S.card}>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <span style={{ fontWeight: 600 }}>{a.patientName}</span>
            <span style={S.badge(a.status === "completed" ? "green" : "blue")}>{a.status}</span>
          </div>
          <div style={{ fontSize: 13, color: "#64748B" }}>{a.reason}</div>
          <div style={{ fontSize: 12, color: "#94A3B8" }}>📅 {new Date(a.date).toLocaleString()}</div>
          {a.status === "booked" && (
            <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
              <button style={{ ...S.btnSuccess, flex: 1 }} onClick={() => updateStatus(a.id, "completed")}>✅ Complete</button>
              <button style={{ ...S.btnDanger, flex: 1 }} onClick={() => updateStatus(a.id, "cancelled")}>❌ Cancel</button>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function DoctorProfilePage({ user }) {
  return (
    <div style={S.pad}>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 12 }}>My Profile</h2>
      <div style={S.card}>
        <div style={{ fontWeight: 600, fontSize: 16 }}>Dr. {user.name}</div>
        <div style={{ color: "#64748B", fontSize: 14, marginTop: 4 }}>📞 {user.phone} · 📧 {user.email}</div>
        <hr style={S.divider} />
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <span>Status</span>
          <span style={S.badge(user.approved ? "green" : "amber")}>{user.approved ? "Active" : "Pending"}</span>
        </div>
      </div>
    </div>
  );
}

// ─── ADMIN PAGES ──────────────────────────────────────────────────────────────
function AdminHome() {
  const [stats, setStats] = useState({ users: 0, pharmacies: 0, orders: 0, pending: 0 });

  useEffect(() => {
    (async () => {
      const users = await db.get("users") || {};
      const orders = await db.get("orders") || [];
      const pending = await db.get("pendingApprovals") || [];
      const approved = await db.get("approvedPharmacies") || [];
      setStats({ users: Object.keys(users).length, pharmacies: approved.length, orders: orders.length, pending: pending.length });
    })();
  }, []);

  return (
    <div style={S.pad}>
      <div style={{ background: "linear-gradient(135deg,#0B6E74,#14949C)", borderRadius: 16, padding: 20, color: "#fff", marginBottom: 16 }}>
        <p style={{ fontSize: 13, opacity: .8 }}>Platform Admin</p>
        <h2 style={{ fontSize: 20, fontWeight: 700 }}>⚙️ Admin Dashboard</h2>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        {[
          { num: stats.users, label: "Total Users", icon: "👥" },
          { num: stats.pharmacies, label: "Pharmacies", icon: "🏪" },
          { num: stats.orders, label: "Orders", icon: "📦" },
          { num: stats.pending, label: "Pending", icon: "⏳" },
        ].map(s => (
          <div key={s.label} style={S.statCard}>
            <div style={{ fontSize: 20 }}>{s.icon}</div>
            <div style={S.statNum}>{s.num}</div>
            <div style={S.statLabel}>{s.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AdminApprovals() {
  const [pending, setPending] = useState([]);
  const [msg, setMsg] = useState("");

  useEffect(() => { loadPending(); }, []);

  const loadPending = async () => {
    const p = await db.get("pendingApprovals") || [];
    setPending(p);
  };

  const approve = async (userId) => {
    const pendingList = await db.get("pendingApprovals") || [];
    const item = pendingList.find(p => p.id === userId);
    if (!item) return;

    // Approve in users
    const users = await db.get("users") || {};
    if (users[item.phone]) {
      users[item.phone].approved = true;
      users[item.phone].licenseVerified = true;
      await db.set("users", users);
    }

    // Add to approved pharmacies if pharmacy
    if (item.role === "pharmacy") {
      const approved = await db.get("approvedPharmacies") || [];
      approved.push({ id: item.id, shopName: item.name, name: item.name, phone: item.phone, address: item.address, openTime: item.openTime, closeTime: item.closeTime });
      await db.set("approvedPharmacies", approved);
    }

    // Remove from pending
    const updated = pendingList.filter(p => p.id !== userId);
    await db.set("pendingApprovals", updated);

    setMsg(`${item.name} approved!`);
    loadPending();
  };

  const reject = async (userId) => {
    const pendingList = await db.get("pendingApprovals") || [];
    const updated = pendingList.filter(p => p.id !== userId);
    await db.set("pendingApprovals", updated);
    loadPending();
  };

  return (
    <div style={S.pad}>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 12 }}>Pending Approvals</h2>
      {msg && <div style={S.success}>{msg}</div>}
      {pending.length === 0 ? (
        <div style={S.empty}><div style={S.emptyIcon}>✅</div><p style={S.emptyText}>No pending approvals</p></div>
      ) : pending.map(p => (
        <div key={p.id} style={S.card}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
            <span style={{ fontWeight: 600 }}>{p.name}</span>
            <span style={S.badge("amber")}>{p.role}</span>
          </div>
          <div style={{ fontSize: 13, color: "#64748B" }}>📞 {p.phone} · 📧 {p.email}</div>
          {p.licenseText && (
            <div style={{ marginTop: 8, background: "#F8FAFC", borderRadius: 8, padding: 10 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: "#0B6E74", marginBottom: 4 }}>🔍 License (OCR Extracted)</div>
              <div style={{ fontSize: 12, color: "#64748B" }}>{p.licenseText.slice(0, 150)}</div>
            </div>
          )}
          <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
            <button style={{ ...S.btnSuccess, flex: 1 }} onClick={() => approve(p.id)}>✅ Approve</button>
            <button style={{ ...S.btnDanger, flex: 1 }} onClick={() => reject(p.id)}>❌ Reject</button>
          </div>
        </div>
      ))}
    </div>
  );
}

function AdminPharmacies() {
  const [pharmacies, setPharmacies] = useState([]);

  useEffect(() => {
    (async () => {
      const approved = await db.get("approvedPharmacies") || [];
      setPharmacies(approved);
    })();
  }, []);

  const remove = async (id) => {
    const updated = pharmacies.filter(p => p.id !== id);
    await db.set("approvedPharmacies", updated);
    setPharmacies(updated);
  };

  return (
    <div style={S.pad}>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 12 }}>Approved Pharmacies</h2>
      {pharmacies.length === 0 ? (
        <div style={S.empty}><div style={S.emptyIcon}>🏪</div><p style={S.emptyText}>No approved pharmacies</p></div>
      ) : pharmacies.map(p => (
        <div key={p.id} style={S.card}>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <div>
              <div style={S.cardTitle}>🏪 {p.shopName || p.name}</div>
              <div style={S.cardSub}>📞 {p.phone}</div>
            </div>
            <button style={S.btnDanger} onClick={() => remove(p.id)}>🗑</button>
          </div>
          <span style={{ ...S.badge("green"), marginTop: 8 }}>Active</span>
        </div>
      ))}
    </div>
  );
}

function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    (async () => {
      const u = await db.get("users") || {};
      setUsers(Object.values(u));
    })();
  }, []);

  const filtered = filter === "all" ? users : users.filter(u => u.role === filter);

  return (
    <div style={S.pad}>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 12 }}>All Users</h2>
      <div style={S.tabs}>
        {["all", "patient", "pharmacy", "doctor"].map(r => (
          <button key={r} style={S.tab(filter === r)} onClick={() => setFilter(r)}>{r.charAt(0).toUpperCase() + r.slice(1)}</button>
        ))}
      </div>
      {filtered.length === 0 ? (
        <div style={S.empty}><div style={S.emptyIcon}>👥</div><p style={S.emptyText}>No users found</p></div>
      ) : filtered.map(u => (
        <div key={u.id} style={S.card}>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <div>
              <div style={S.cardTitle}>{u.name}</div>
              <div style={S.cardSub}>📞 {u.phone} · {u.role}</div>
            </div>
            <span style={S.badge(u.approved ? "green" : "amber")}>{u.approved ? "Active" : "Pending"}</span>
          </div>
        </div>
      ))}
    </div>
  );
}
