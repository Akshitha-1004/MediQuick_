// server.js — MediQuick Backend Entry Point
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const swaggerUi = require('swagger-ui-express');
const path = require('path');

const connectDB = require('./config/db');
const swaggerSpec = require('./config/swagger');
const errorHandler = require('./middleware/errorHandler');

// ── Routes ─────────────────────────────────────────
const authRoutes        = require('./routes/auth');
const medicineRoutes    = require('./routes/medicines');
const pharmacyRoutes    = require('./routes/pharmacies');
const orderRoutes       = require('./routes/orders');
const doctorRoutes      = require('./routes/doctors');
const adminRoutes       = require('./routes/admin');

// ── DB ──────────────────────────────────────────────
connectDB();

const app = express();

// ── Security & Middleware ───────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: process.env.CLIENT_URL || '*',
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

// ── Rate limiting ───────────────────────────────────
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 200, message: 'Too many requests' });
const otpLimiter = rateLimit({ windowMs: 10 * 60 * 1000, max: 5, message: 'Too many OTP requests' });
app.use('/api/', limiter);
app.use('/api/v1/auth/send-otp', otpLimiter);

// ── Static uploads ──────────────────────────────────
app.use('/uploads', express.static(path.join(__dirname, process.env.UPLOAD_DIR || 'uploads')));

// ── Swagger UI ──────────────────────────────────────
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec, {
  customSiteTitle: 'MediQuick API Docs',
  customCss: '.swagger-ui .topbar { background-color: #0B6E74; }',
  swaggerOptions: { persistAuthorization: true },
}));

// Raw JSON spec endpoint
app.get('/api-docs.json', (req, res) => res.json(swaggerSpec));

// ── API Routes ──────────────────────────────────────
const API = '/api/v1';
app.use(`${API}/auth`,       authRoutes);
app.use(`${API}/medicines`,  medicineRoutes);
app.use(`${API}/pharmacies`, pharmacyRoutes);
app.use(`${API}/orders`,     orderRoutes);
app.use(`${API}/doctors`,    doctorRoutes);
app.use(`${API}/admin`,      adminRoutes);

// ── Health check ────────────────────────────────────
app.get('/health', (req, res) =>
  res.json({ status: 'ok', service: 'MediQuick API', version: '1.0.0', env: process.env.NODE_ENV })
);

// ── 404 ─────────────────────────────────────────────
app.use((req, res) => res.status(404).json({ success: false, message: `Route ${req.originalUrl} not found` }));

// ── Global error handler ────────────────────────────
app.use(errorHandler);

// ── Start ───────────────────────────────────────────
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`\n🚀 MediQuick API running on http://localhost:${PORT}`);
  console.log(`📖 Swagger docs: http://localhost:${PORT}/api-docs`);
  console.log(`🌿 Environment: ${process.env.NODE_ENV || 'development'}\n`);
});

module.exports = app;
