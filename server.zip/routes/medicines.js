// routes/medicines.js
const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const Medicine = require('../models/Medicine');
const Inventory = require('../models/Inventory');

/**
 * @swagger
 * tags:
 *   name: Medicines
 *   description: Medicine catalogue and search
 */

/**
 * @swagger
 * /medicines:
 *   get:
 *     tags: [Medicines]
 *     summary: Get all medicines (with search + filter)
 *     security: []
 *     parameters:
 *       - in: query
 *         name: q
 *         schema: { type: string }
 *         description: Search by name or generic name
 *       - in: query
 *         name: category
 *         schema: { type: string }
 *       - in: query
 *         name: requiresPrescription
 *         schema: { type: boolean }
 *       - in: query
 *         name: page
 *         schema: { type: integer, default: 1 }
 *       - in: query
 *         name: limit
 *         schema: { type: integer, default: 20 }
 *     responses:
 *       200:
 *         description: List of medicines
 */
router.get('/', async (req, res, next) => {
  try {
    const { q, category, requiresPrescription, page = 1, limit = 20 } = req.query;
    const query = { isActive: true };

    if (q) query.$text = { $search: q };
    if (category) query.category = category;
    if (requiresPrescription !== undefined) query.requiresPrescription = requiresPrescription === 'true';

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const [medicines, total] = await Promise.all([
      Medicine.find(query).skip(skip).limit(parseInt(limit)).sort({ name: 1 }),
      Medicine.countDocuments(query),
    ]);

    res.json({ success: true, data: medicines, total, page: parseInt(page), pages: Math.ceil(total / parseInt(limit)) });
  } catch (err) { next(err); }
});

/**
 * @swagger
 * /medicines/{id}:
 *   get:
 *     tags: [Medicines]
 *     summary: Get a single medicine by ID
 *     security: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Medicine object
 *       404:
 *         description: Not found
 */
router.get('/:id', async (req, res, next) => {
  try {
    const med = await Medicine.findById(req.params.id);
    if (!med) return res.status(404).json({ success: false, message: 'Medicine not found' });
    res.json({ success: true, data: med });
  } catch (err) { next(err); }
});

/**
 * @swagger
 * /medicines:
 *   post:
 *     tags: [Medicines]
 *     summary: Add a new medicine to the catalogue (Admin only)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema: { $ref: '#/components/schemas/Medicine' }
 *     responses:
 *       201:
 *         description: Medicine created
 */
router.post('/', protect, authorize('admin'), async (req, res, next) => {
  try {
    const medicine = await Medicine.create(req.body);
    res.status(201).json({ success: true, data: medicine });
  } catch (err) { next(err); }
});

/**
 * @swagger
 * /medicines/{id}:
 *   put:
 *     tags: [Medicines]
 *     summary: Update a medicine (Admin only)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       content:
 *         application/json:
 *           schema: { $ref: '#/components/schemas/Medicine' }
 *     responses:
 *       200:
 *         description: Updated medicine
 */
router.put('/:id', protect, authorize('admin'), async (req, res, next) => {
  try {
    const medicine = await Medicine.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!medicine) return res.status(404).json({ success: false, message: 'Medicine not found' });
    res.json({ success: true, data: medicine });
  } catch (err) { next(err); }
});

module.exports = router;
