// routes/doctors.js
const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const DoctorProfile = require('../models/DoctorProfile');
const Slot = require('../models/Slot');
const Appointment = require('../models/Appointment');

/**
 * @swagger
 * tags:
 *   name: Doctors
 *   description: Doctor listing, slots, and appointments
 */

// ── GET /doctors ───────────────────────────────────────────────────────────
/**
 * @swagger
 * /doctors:
 *   get:
 *     tags: [Doctors]
 *     summary: List all approved doctors
 *     security: []
 *     parameters:
 *       - in: query
 *         name: specialization
 *         schema: { type: string }
 *       - in: query
 *         name: q
 *         schema: { type: string }
 *         description: Search by name or hospital
 *     responses:
 *       200:
 *         description: List of doctors
 */
router.get('/', async (req, res, next) => {
  try {
    const { specialization, q } = req.query;
    const filter = { status: 'approved' };
    if (specialization) filter.specialization = new RegExp(specialization, 'i');

    let doctors = await DoctorProfile.find(filter)
      .populate('user', 'name phone')
      .sort({ rating: -1 });

    if (q) {
      const re = new RegExp(q, 'i');
      doctors = doctors.filter(d => re.test(d.user?.name) || re.test(d.hospital) || re.test(d.specialization));
    }

    res.json({ success: true, data: doctors });
  } catch (err) { next(err); }
});

// ── GET /doctors/:id ────────────────────────────────────────────────────────
/**
 * @swagger
 * /doctors/{id}:
 *   get:
 *     tags: [Doctors]
 *     summary: Get a doctor's full profile
 *     security: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Doctor profile
 */
router.get('/:id', async (req, res, next) => {
  try {
    const doctor = await DoctorProfile.findById(req.params.id).populate('user', 'name phone');
    if (!doctor) return res.status(404).json({ success: false, message: 'Doctor not found' });
    res.json({ success: true, data: doctor });
  } catch (err) { next(err); }
});

// ── GET /doctors/:id/slots — available slots for a date ───────────────────
/**
 * @swagger
 * /doctors/{id}/slots:
 *   get:
 *     tags: [Doctors]
 *     summary: Get available slots for a doctor on a date
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *       - in: query
 *         name: date
 *         required: true
 *         schema: { type: string, format: date, example: "2025-06-15" }
 *     responses:
 *       200:
 *         description: List of slots
 */
router.get('/:id/slots', async (req, res, next) => {
  try {
    const { date } = req.query;
    if (!date) return res.status(400).json({ success: false, message: 'date query param required' });

    const slots = await Slot.find({ doctor: req.params.id, date, isActive: true }).sort({ time: 1 });
    res.json({ success: true, data: slots });
  } catch (err) { next(err); }
});

// ── POST /doctors/slots — doctor adds slots ────────────────────────────────
/**
 * @swagger
 * /doctors/slots:
 *   post:
 *     tags: [Doctors]
 *     summary: Add availability slots (Doctor role)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [date, times]
 *             properties:
 *               date:
 *                 type: string
 *                 format: date
 *                 example: "2025-06-15"
 *               times:
 *                 type: array
 *                 items: { type: string }
 *                 example: ["09:00", "09:30", "10:00"]
 *     responses:
 *       201:
 *         description: Slots created
 */
router.post('/slots', protect, authorize('doctor'), async (req, res, next) => {
  try {
    const { date, times } = req.body;
    const doctorProfile = await DoctorProfile.findOne({ user: req.user._id });
    if (!doctorProfile) return res.status(404).json({ success: false, message: 'Doctor profile not found' });

    const slots = await Promise.all(
      times.map(time =>
        Slot.findOneAndUpdate(
          { doctor: doctorProfile._id, date, time },
          { doctor: doctorProfile._id, date, time, isActive: true },
          { upsert: true, new: true }
        )
      )
    );

    res.status(201).json({ success: true, message: `${slots.length} slots saved`, data: slots });
  } catch (err) { next(err); }
});

// ── POST /doctors/:id/book — customer books appointment ───────────────────
/**
 * @swagger
 * /doctors/{id}/book:
 *   post:
 *     tags: [Doctors]
 *     summary: Book an appointment (Customer)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *         description: DoctorProfile ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [slotId, reason]
 *             properties:
 *               slotId: { type: string }
 *               reason: { type: string, example: Fever and cough }
 *     responses:
 *       201:
 *         description: Appointment booked
 *       409:
 *         description: Slot already taken
 */
router.post('/:id/book', protect, authorize('customer'), async (req, res, next) => {
  try {
    const { slotId, reason } = req.body;

    const slot = await Slot.findById(slotId);
    if (!slot || !slot.isActive) return res.status(404).json({ success: false, message: 'Slot not found' });
    if (slot.isBooked) return res.status(409).json({ success: false, message: 'Slot already booked' });

    const doctor = await DoctorProfile.findById(req.params.id);
    if (!doctor) return res.status(404).json({ success: false, message: 'Doctor not found' });

    slot.isBooked = true;
    slot.bookedBy = req.user._id;
    await slot.save();

    const appointment = await Appointment.create({
      patient: req.user._id,
      doctor: doctor._id,
      slot: slot._id,
      reason,
      consultationFee: doctor.consultationFee,
    });

    res.status(201).json({ success: true, message: 'Appointment booked', data: appointment });
  } catch (err) { next(err); }
});

// ── GET /doctors/appointments/my — patient's appointments ─────────────────
/**
 * @swagger
 * /doctors/appointments/my:
 *   get:
 *     tags: [Doctors]
 *     summary: Get current patient's appointments
 *     responses:
 *       200:
 *         description: List of appointments
 */
router.get('/appointments/my', protect, authorize('customer'), async (req, res, next) => {
  try {
    const appointments = await Appointment.find({ patient: req.user._id })
      .populate({ path: 'doctor', populate: { path: 'user', select: 'name' } })
      .populate('slot', 'date time')
      .sort({ createdAt: -1 });
    res.json({ success: true, data: appointments });
  } catch (err) { next(err); }
});

// ── GET /doctors/appointments/incoming — doctor sees their appointments ────
/**
 * @swagger
 * /doctors/appointments/incoming:
 *   get:
 *     tags: [Doctors]
 *     summary: Get incoming appointments for the doctor
 *     responses:
 *       200:
 *         description: Appointment list
 */
router.get('/appointments/incoming', protect, authorize('doctor'), async (req, res, next) => {
  try {
    const doctorProfile = await DoctorProfile.findOne({ user: req.user._id });
    if (!doctorProfile) return res.status(404).json({ success: false, message: 'Doctor profile not found' });

    const appointments = await Appointment.find({ doctor: doctorProfile._id })
      .populate('patient', 'name phone')
      .populate('slot', 'date time')
      .sort({ createdAt: -1 });

    res.json({ success: true, data: appointments });
  } catch (err) { next(err); }
});

// ── PATCH /doctors/appointments/:id — doctor updates appointment ───────────
/**
 * @swagger
 * /doctors/appointments/{id}:
 *   patch:
 *     tags: [Doctors]
 *     summary: Update appointment (complete, add notes/prescription)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               status: { type: string, enum: [completed, cancelled, no_show] }
 *               diagnosis: { type: string }
 *               prescription: { type: string }
 *               notes: { type: string }
 *     responses:
 *       200:
 *         description: Appointment updated
 */
router.patch('/appointments/:id', protect, authorize('doctor'), async (req, res, next) => {
  try {
    const doctorProfile = await DoctorProfile.findOne({ user: req.user._id });
    const appt = await Appointment.findOne({ _id: req.params.id, doctor: doctorProfile._id });
    if (!appt) return res.status(404).json({ success: false, message: 'Appointment not found' });

    Object.assign(appt, req.body);
    await appt.save();
    res.json({ success: true, data: appt });
  } catch (err) { next(err); }
});

module.exports = router;
