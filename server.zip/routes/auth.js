// routes/auth.js
const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const {
  sendOtp, verifyOtp, registerPharmacy, registerDoctor, getMe,
} = require('../controllers/authController');

/**
 * @swagger
 * tags:
 *   name: Auth
 *   description: OTP-based authentication and registration
 */

/**
 * @swagger
 * /auth/send-otp:
 *   post:
 *     tags: [Auth]
 *     summary: Send OTP to a phone number
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [phone]
 *             properties:
 *               phone:
 *                 type: string
 *                 example: "+919876543210"
 *     responses:
 *       200:
 *         description: OTP sent successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success: { type: boolean, example: true }
 *                 message: { type: string, example: OTP sent }
 *                 otp: { type: string, description: "Only in development mode" }
 */
router.post('/send-otp', sendOtp);

/**
 * @swagger
 * /auth/verify-otp:
 *   post:
 *     tags: [Auth]
 *     summary: Verify OTP and get JWT token
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [phone, otp]
 *             properties:
 *               phone:
 *                 type: string
 *                 example: "+919876543210"
 *               otp:
 *                 type: string
 *                 example: "123456"
 *               name:
 *                 type: string
 *                 description: Required for new users
 *                 example: Arjun Verma
 *               role:
 *                 type: string
 *                 enum: [customer, pharmacy, doctor]
 *                 description: Required for new users
 *     responses:
 *       200:
 *         description: JWT token + user info
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success: { type: boolean }
 *                 token: { type: string }
 *                 user: { $ref: '#/components/schemas/User' }
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 */
router.post('/verify-otp', verifyOtp);

/**
 * @swagger
 * /auth/register/pharmacy:
 *   post:
 *     tags: [Auth]
 *     summary: Register pharmacy details (after OTP login as pharmacy role)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [shopName, drugLicense]
 *             properties:
 *               shopName: { type: string, example: HealthMart Pharmacy }
 *               drugLicense: { type: string, example: DL-TG-987654 }
 *               gstNumber: { type: string }
 *               openTime: { type: string, example: "09:00" }
 *               closeTime: { type: string, example: "21:00" }
 *               address:
 *                 type: object
 *                 properties:
 *                   street: { type: string }
 *                   area: { type: string }
 *                   city: { type: string }
 *                   pincode: { type: string }
 *     responses:
 *       201:
 *         description: Pharmacy profile submitted for approval
 */
router.post('/register/pharmacy', protect, registerPharmacy);

/**
 * @swagger
 * /auth/register/doctor:
 *   post:
 *     tags: [Auth]
 *     summary: Register doctor details (after OTP login as doctor role)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [specialization, registrationNo, hospital]
 *             properties:
 *               specialization: { type: string, example: General Physician }
 *               registrationNo: { type: string, example: MCI-12345 }
 *               hospital: { type: string, example: Apollo Hospital }
 *               experience: { type: number, example: 8 }
 *               consultationFee: { type: number, example: 300 }
 *               qualifications: { type: array, items: { type: string }, example: [MBBS, MD] }
 *     responses:
 *       201:
 *         description: Doctor profile submitted for approval
 */
router.post('/register/doctor', protect, registerDoctor);

/**
 * @swagger
 * /auth/me:
 *   get:
 *     tags: [Auth]
 *     summary: Get current logged-in user profile
 *     responses:
 *       200:
 *         description: Current user data with profile
 */
router.get('/me', protect, getMe);

module.exports = router;
