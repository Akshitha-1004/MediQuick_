// routes/admin.js
const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const User = require('../models/User');
const PharmacyProfile = require('../models/PharmacyProfile');
const DoctorProfile = require('../models/DoctorProfile');
const Order = require('../models/Order');
const Appointment = require('../models/Appointment');

// All admin routes require authentication and admin role
router.use(protect, authorize('admin'));

/**
 * @swagger
 * tags:
 *   name: Admin
 *   description: Platform administration (Admin role only)
 */

// ── Dashboard stats ────────────────────────────────────────────────────────
/**
 * @swagger
 * /admin/dashboard:
 *   get:
 *     tags: [Admin]
 *     summary: Get platform-wide dashboard statistics
 *     responses:
 *       200:
 *         description: Stats object
 */
router.get('/dashboard', async (req, res, next) => {
  try {
    const [
      totalUsers, totalPharmacies, totalDoctors,
      pendingPharmacies, pendingDoctors,
      totalOrders, todayOrders,
    ] = await Promise.all([
      User.countDocuments({ role: 'customer' }),
      PharmacyProfile.countDocuments({ status: 'approved' }),
      DoctorProfile.countDocuments({ status: 'approved' }),
      PharmacyProfile.countDocuments({ status: 'pending' }),
      DoctorProfile.countDocuments({ status: 'pending' }),
      Order.countDocuments(),
      Order.countDocuments({ createdAt: { $gte: new Date(new Date().setHours(0,0,0,0)) } }),
    ]);

    res.json({
      success: true,
      data: { totalUsers, totalPharmacies, totalDoctors, pendingPharmacies, pendingDoctors, totalOrders, todayOrders },
    });
  } catch (err) { next(err); }
});

// ── Pending pharmacy approvals ─────────────────────────────────────────────
/**
 * @swagger
 * /admin/pharmacies/pending:
 *   get:
 *     tags: [Admin]
 *     summary: List pharmacies pending approval
 *     responses:
 *       200:
 *         description: Pending pharmacy list
 */
router.get('/pharmacies/pending', async (req, res, next) => {
  try {
    const pharmacies = await PharmacyProfile.find({ status: 'pending' }).populate('owner', 'name phone email').sort({ createdAt: 1 });
    res.json({ success: true, data: pharmacies });
  } catch (err) { next(err); }
});

// ── Approve / reject pharmacy ─────────────────────────────────────────────
/**
 * @swagger
 * /admin/pharmacies/{id}/approve:
 *   patch:
 *     tags: [Admin]
 *     summary: Approve a pharmacy
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Pharmacy approved
 */
router.patch('/pharmacies/:id/approve', async (req, res, next) => {
  try {
    const pharmacy = await PharmacyProfile.findByIdAndUpdate(req.params.id, { status: 'approved' }, { new: true });
    if (!pharmacy) return res.status(404).json({ success: false, message: 'Pharmacy not found' });
    res.json({ success: true, message: 'Pharmacy approved', data: pharmacy });
  } catch (err) { next(err); }
});

/**
 * @swagger
 * /admin/pharmacies/{id}/reject:
 *   patch:
 *     tags: [Admin]
 *     summary: Reject a pharmacy registration
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               reason: { type: string }
 *     responses:
 *       200:
 *         description: Pharmacy rejected
 */
router.patch('/pharmacies/:id/reject', async (req, res, next) => {
  try {
    const pharmacy = await PharmacyProfile.findByIdAndUpdate(
      req.params.id,
      { status: 'rejected', rejectionReason: req.body.reason || 'Not specified' },
      { new: true }
    );
    if (!pharmacy) return res.status(404).json({ success: false, message: 'Pharmacy not found' });
    res.json({ success: true, message: 'Pharmacy rejected', data: pharmacy });
  } catch (err) { next(err); }
});

// ── Pending doctor approvals ───────────────────────────────────────────────
/**
 * @swagger
 * /admin/doctors/pending:
 *   get:
 *     tags: [Admin]
 *     summary: List doctors pending approval
 *     responses:
 *       200:
 *         description: Pending doctors
 */
router.get('/doctors/pending', async (req, res, next) => {
  try {
    const doctors = await DoctorProfile.find({ status: 'pending' }).populate('user', 'name phone email').sort({ createdAt: 1 });
    res.json({ success: true, data: doctors });
  } catch (err) { next(err); }
});

/**
 * @swagger
 * /admin/doctors/{id}/approve:
 *   patch:
 *     tags: [Admin]
 *     summary: Approve a doctor
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Doctor approved
 */
router.patch('/doctors/:id/approve', async (req, res, next) => {
  try {
    const doctor = await DoctorProfile.findByIdAndUpdate(req.params.id, { status: 'approved' }, { new: true });
    if (!doctor) return res.status(404).json({ success: false, message: 'Doctor not found' });
    res.json({ success: true, message: 'Doctor approved', data: doctor });
  } catch (err) { next(err); }
});

/**
 * @swagger
 * /admin/doctors/{id}/reject:
 *   patch:
 *     tags: [Admin]
 *     summary: Reject a doctor registration
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               reason: { type: string }
 *     responses:
 *       200:
 *         description: Doctor rejected
 */
router.patch('/doctors/:id/reject', async (req, res, next) => {
  try {
    const doctor = await DoctorProfile.findByIdAndUpdate(
      req.params.id,
      { status: 'rejected', rejectionReason: req.body.reason || 'Not specified' },
      { new: true }
    );
    if (!doctor) return res.status(404).json({ success: false, message: 'Doctor not found' });
    res.json({ success: true, message: 'Doctor rejected', data: doctor });
  } catch (err) { next(err); }
});

// ── All users ──────────────────────────────────────────────────────────────
/**
 * @swagger
 * /admin/users:
 *   get:
 *     tags: [Admin]
 *     summary: Get all platform users
 *     parameters:
 *       - in: query
 *         name: role
 *         schema: { type: string, enum: [customer, pharmacy, doctor, admin] }
 *       - in: query
 *         name: page
 *         schema: { type: integer, default: 1 }
 *     responses:
 *       200:
 *         description: Paginated user list
 */
router.get('/users', async (req, res, next) => {
  try {
    const { role, page = 1, limit = 20 } = req.query;
    const filter = {};
    if (role) filter.role = role;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const [users, total] = await Promise.all([
      User.find(filter).skip(skip).limit(parseInt(limit)).sort({ createdAt: -1 }),
      User.countDocuments(filter),
    ]);
    res.json({ success: true, data: users, total, page: parseInt(page), pages: Math.ceil(total / parseInt(limit)) });
  } catch (err) { next(err); }
});

// ── Suspend / activate user ────────────────────────────────────────────────
/**
 * @swagger
 * /admin/users/{id}/suspend:
 *   patch:
 *     tags: [Admin]
 *     summary: Suspend a user account
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: User suspended
 */
router.patch('/users/:id/suspend', async (req, res, next) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, { isActive: false }, { new: true });
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    res.json({ success: true, message: 'User suspended', data: user });
  } catch (err) { next(err); }
});

/**
 * @swagger
 * /admin/users/{id}/activate:
 *   patch:
 *     tags: [Admin]
 *     summary: Reactivate a user account
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: User activated
 */
router.patch('/users/:id/activate', async (req, res, next) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, { isActive: true }, { new: true });
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    res.json({ success: true, message: 'User activated', data: user });
  } catch (err) { next(err); }
});

module.exports = router;
