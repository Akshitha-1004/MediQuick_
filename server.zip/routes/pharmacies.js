// routes/pharmacies.js
const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const PharmacyProfile = require('../models/PharmacyProfile');
const Inventory = require('../models/Inventory');
const Medicine = require('../models/Medicine');

/**
 * @swagger
 * tags:
 *   name: Pharmacies
 *   description: Pharmacy listing, inventory, and order management
 */

// ── GET /pharmacies — public list of approved pharmacies ──────────────────
/**
 * @swagger
 * /pharmacies:
 *   get:
 *     tags: [Pharmacies]
 *     summary: List all approved pharmacies (optionally nearby)
 *     security: []
 *     parameters:
 *       - in: query
 *         name: lat
 *         schema: { type: number }
 *         description: Customer latitude for nearby search
 *       - in: query
 *         name: lng
 *         schema: { type: number }
 *         description: Customer longitude
 *       - in: query
 *         name: radius
 *         schema: { type: number, default: 10 }
 *         description: Radius in km
 *     responses:
 *       200:
 *         description: List of approved pharmacies
 */
router.get('/', async (req, res, next) => {
  try {
    const { lat, lng, radius = 10 } = req.query;
    let filter = { status: 'approved' };
    let query;

    if (lat && lng) {
      query = PharmacyProfile.find({
        ...filter,
        location: {
          $near: {
            $geometry: { type: 'Point', coordinates: [parseFloat(lng), parseFloat(lat)] },
            $maxDistance: radius * 1000,
          },
        },
      });
    } else {
      query = PharmacyProfile.find(filter).sort({ rating: -1 });
    }

    const pharmacies = await query.populate('owner', 'name phone').limit(20);
    res.json({ success: true, data: pharmacies });
  } catch (err) { next(err); }
});

// ── GET /pharmacies/:id ────────────────────────────────────────────────────
/**
 * @swagger
 * /pharmacies/{id}:
 *   get:
 *     tags: [Pharmacies]
 *     summary: Get a single pharmacy profile
 *     security: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Pharmacy profile
 */
router.get('/:id', async (req, res, next) => {
  try {
    const pharmacy = await PharmacyProfile.findById(req.params.id).populate('owner', 'name phone');
    if (!pharmacy) return res.status(404).json({ success: false, message: 'Pharmacy not found' });
    res.json({ success: true, data: pharmacy });
  } catch (err) { next(err); }
});

// ── GET /pharmacies/:id/inventory ─────────────────────────────────────────
/**
 * @swagger
 * /pharmacies/{id}/inventory:
 *   get:
 *     tags: [Pharmacies]
 *     summary: Get inventory of a pharmacy
 *     security: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *       - in: query
 *         name: q
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Inventory list
 */
router.get('/:id/inventory', async (req, res, next) => {
  try {
    const { q } = req.query;
    const filter = { pharmacy: req.params.id, stock: { $gt: 0 } };
    let items = await Inventory.find(filter).populate('medicine').lean();

    if (q) {
      const re = new RegExp(q, 'i');
      items = items.filter(i => re.test(i.medicine?.name) || re.test(i.medicine?.genericName));
    }

    // Attach virtual
    items = items.map(i => ({
      ...i,
      stockStatus: i.stock === 0 ? 'out_of_stock' : i.stock <= (i.lowStockThreshold || 20) ? 'low_stock' : 'in_stock',
    }));

    res.json({ success: true, data: items });
  } catch (err) { next(err); }
});

// ── POST /pharmacies/inventory — add/update stock (pharmacy only) ──────────
/**
 * @swagger
 * /pharmacies/inventory:
 *   post:
 *     tags: [Pharmacies]
 *     summary: Add or update stock (Pharmacy role)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [medicineId, stock, sellingPrice]
 *             properties:
 *               medicineId: { type: string }
 *               stock: { type: number, example: 100 }
 *               sellingPrice: { type: number, example: 15.5 }
 *               expiryDate: { type: string, format: date }
 *               batchNumber: { type: string }
 *     responses:
 *       200:
 *         description: Inventory updated
 */
router.post('/inventory', protect, authorize('pharmacy'), async (req, res, next) => {
  try {
    const { medicineId, stock, sellingPrice, expiryDate, batchNumber } = req.body;
    const pharmacyProfile = await PharmacyProfile.findOne({ owner: req.user._id });
    if (!pharmacyProfile) return res.status(404).json({ success: false, message: 'Pharmacy profile not found' });

    const item = await Inventory.findOneAndUpdate(
      { pharmacy: pharmacyProfile._id, medicine: medicineId },
      { stock, sellingPrice, expiryDate, batchNumber },
      { upsert: true, new: true, runValidators: true }
    ).populate('medicine');

    res.json({ success: true, data: item });
  } catch (err) { next(err); }
});

// ── PUT /pharmacies/inventory/:itemId ─────────────────────────────────────
/**
 * @swagger
 * /pharmacies/inventory/{itemId}:
 *   put:
 *     tags: [Pharmacies]
 *     summary: Update a specific inventory item (Pharmacy role)
 *     parameters:
 *       - in: path
 *         name: itemId
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               stock: { type: number }
 *               sellingPrice: { type: number }
 *     responses:
 *       200:
 *         description: Updated
 */
router.put('/inventory/:itemId', protect, authorize('pharmacy'), async (req, res, next) => {
  try {
    const item = await Inventory.findByIdAndUpdate(req.params.itemId, req.body, { new: true }).populate('medicine');
    if (!item) return res.status(404).json({ success: false, message: 'Inventory item not found' });
    res.json({ success: true, data: item });
  } catch (err) { next(err); }
});

module.exports = router;
