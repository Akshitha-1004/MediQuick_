// routes/orders.js
const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const upload = require('../middleware/upload');
const Order = require('../models/Order');
const Inventory = require('../models/Inventory');
const PharmacyProfile = require('../models/PharmacyProfile');

/**
 * @swagger
 * tags:
 *   name: Orders
 *   description: Medicine order placement and tracking
 */

// ── POST /orders — place order (customer) ─────────────────────────────────
/**
 * @swagger
 * /orders:
 *   post:
 *     tags: [Orders]
 *     summary: Place a new medicine order (Customer)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [pharmacyId, items, deliveryAddress, paymentMode]
 *             properties:
 *               pharmacyId: { type: string }
 *               items:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     medicineId: { type: string }
 *                     quantity: { type: number }
 *               deliveryAddress:
 *                 type: object
 *                 properties:
 *                   street: { type: string }
 *                   city: { type: string }
 *                   pincode: { type: string }
 *               paymentMode:
 *                 type: string
 *                 enum: [cod, upi, card, wallet]
 *     responses:
 *       201:
 *         description: Order placed
 */
router.post('/', protect, authorize('customer'), async (req, res, next) => {
  try {
    const { pharmacyId, items, deliveryAddress, paymentMode } = req.body;

    // Build order items and calculate total
    let subtotal = 0;
    const orderItems = [];

    for (const item of items) {
      const inv = await Inventory.findOne({ pharmacy: pharmacyId, medicine: item.medicineId }).populate('medicine');
      if (!inv || inv.stock < item.quantity) {
        return res.status(400).json({ success: false, message: `Insufficient stock for ${inv?.medicine?.name || item.medicineId}` });
      }
      orderItems.push({
        medicine: item.medicineId,
        medicineName: inv.medicine.name,
        quantity: item.quantity,
        price: inv.sellingPrice,
      });
      subtotal += inv.sellingPrice * item.quantity;

      // Decrement stock
      inv.stock -= item.quantity;
      await inv.save();
    }

    const deliveryCharge = 40;
    const order = await Order.create({
      customer: req.user._id,
      pharmacy: pharmacyId,
      items: orderItems,
      subtotal,
      deliveryCharge,
      totalAmount: subtotal + deliveryCharge,
      deliveryAddress,
      paymentMode,
      statusHistory: [{ status: 'pending', note: 'Order placed' }],
    });

    res.status(201).json({ success: true, message: 'Order placed successfully', data: order });
  } catch (err) { next(err); }
});

// ── GET /orders/my — customer's own orders ────────────────────────────────
/**
 * @swagger
 * /orders/my:
 *   get:
 *     tags: [Orders]
 *     summary: Get current customer's orders
 *     responses:
 *       200:
 *         description: List of customer orders
 */
router.get('/my', protect, authorize('customer'), async (req, res, next) => {
  try {
    const orders = await Order.find({ customer: req.user._id })
      .populate('pharmacy', 'shopName address')
      .populate('items.medicine', 'name')
      .sort({ createdAt: -1 });
    res.json({ success: true, data: orders });
  } catch (err) { next(err); }
});

// ── GET /orders/pharmacy — pharmacy's incoming orders ─────────────────────
/**
 * @swagger
 * /orders/pharmacy:
 *   get:
 *     tags: [Orders]
 *     summary: Get all orders for the logged-in pharmacy
 *     parameters:
 *       - in: query
 *         name: status
 *         schema: { type: string, enum: [pending, accepted, packed, out_for_delivery, delivered, rejected, cancelled] }
 *     responses:
 *       200:
 *         description: Pharmacy orders list
 */
router.get('/pharmacy', protect, authorize('pharmacy'), async (req, res, next) => {
  try {
    const pharmacyProfile = await PharmacyProfile.findOne({ owner: req.user._id });
    if (!pharmacyProfile) return res.status(404).json({ success: false, message: 'Pharmacy profile not found' });

    const { status } = req.query;
    const filter = { pharmacy: pharmacyProfile._id };
    if (status) filter.status = status;

    const orders = await Order.find(filter)
      .populate('customer', 'name phone address')
      .populate('items.medicine', 'name')
      .sort({ createdAt: -1 });

    res.json({ success: true, data: orders });
  } catch (err) { next(err); }
});

// ── GET /orders/:id ────────────────────────────────────────────────────────
/**
 * @swagger
 * /orders/{id}:
 *   get:
 *     tags: [Orders]
 *     summary: Get order by ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Order details
 */
router.get('/:id', protect, async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate('pharmacy', 'shopName address')
      .populate('customer', 'name phone')
      .populate('items.medicine', 'name genericName');

    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });

    // Ownership check
    const isOwner = order.customer._id.toString() === req.user._id.toString();
    const pharmacyProfile = await PharmacyProfile.findOne({ owner: req.user._id });
    const isPharmacy = pharmacyProfile && order.pharmacy._id.toString() === pharmacyProfile._id.toString();
    const isAdmin = req.user.role === 'admin';

    if (!isOwner && !isPharmacy && !isAdmin) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    res.json({ success: true, data: order });
  } catch (err) { next(err); }
});

// ── PATCH /orders/:id/status — pharmacy updates order status ──────────────
/**
 * @swagger
 * /orders/{id}/status:
 *   patch:
 *     tags: [Orders]
 *     summary: Update order status (Pharmacy or Admin)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [status]
 *             properties:
 *               status:
 *                 type: string
 *                 enum: [accepted, packed, out_for_delivery, delivered, rejected]
 *               note: { type: string }
 *               rejectionReason: { type: string }
 *     responses:
 *       200:
 *         description: Status updated
 */
router.patch('/:id/status', protect, authorize('pharmacy', 'admin'), async (req, res, next) => {
  try {
    const { status, note, rejectionReason } = req.body;
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });

    order.status = status;
    order.statusHistory.push({ status, note: note || '' });
    if (rejectionReason) order.rejectionReason = rejectionReason;
    if (status === 'delivered') order.paymentStatus = 'paid';

    await order.save();
    res.json({ success: true, message: `Order ${status}`, data: order });
  } catch (err) { next(err); }
});

// ── POST /orders/:id/prescription — upload prescription ───────────────────
/**
 * @swagger
 * /orders/{id}/prescription:
 *   post:
 *     tags: [Orders]
 *     summary: Upload prescription for an order
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               prescription:
 *                 type: string
 *                 format: binary
 *     responses:
 *       200:
 *         description: Prescription uploaded
 */
router.post('/:id/prescription', protect, authorize('customer'), upload.single('prescription'), async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });
    if (order.customer.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not your order' });
    }
    order.prescriptionUrl = `/uploads/${req.file.filename}`;
    await order.save();
    res.json({ success: true, message: 'Prescription uploaded', prescriptionUrl: order.prescriptionUrl });
  } catch (err) { next(err); }
});

// ── PATCH /orders/:id/cancel ───────────────────────────────────────────────
/**
 * @swagger
 * /orders/{id}/cancel:
 *   patch:
 *     tags: [Orders]
 *     summary: Cancel an order (Customer, only if pending)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Order cancelled
 */
router.patch('/:id/cancel', protect, authorize('customer'), async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });
    if (order.customer.toString() !== req.user._id.toString()) return res.status(403).json({ success: false, message: 'Not your order' });
    if (!['pending', 'accepted'].includes(order.status)) return res.status(400).json({ success: false, message: `Cannot cancel order in '${order.status}' state` });

    order.status = 'cancelled';
    order.statusHistory.push({ status: 'cancelled', note: 'Cancelled by customer' });
    await order.save();

    // Restore stock
    for (const item of order.items) {
      await Inventory.findOneAndUpdate(
        { pharmacy: order.pharmacy, medicine: item.medicine },
        { $inc: { stock: item.quantity } }
      );
    }

    res.json({ success: true, message: 'Order cancelled' });
  } catch (err) { next(err); }
});

module.exports = router;
