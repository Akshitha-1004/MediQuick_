// config/swagger.js
const swaggerJsdoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'MediQuick API',
      version: '1.0.0',
      description: `
## MediQuick Healthcare Platform API

Complete REST API for the MediQuick platform serving 4 roles:
- **Customer** — Browse pharmacies, order medicines, book doctor appointments
- **Pharmacy** — Manage inventory, process orders, get approvals
- **Doctor** — Manage slots, view appointments
- **Admin** — Approve pharmacies/doctors, manage users

### Authentication
All protected routes require a Bearer JWT token in the Authorization header.
\`\`\`
Authorization: Bearer <token>
\`\`\`
      `,
      contact: { name: 'MediQuick Dev Team', email: 'dev@mediquick.in' },
    },
    servers: [
      { url: 'http://localhost:5000/api/v1', description: 'Development' },
      { url: 'https://api.mediquick.in/api/v1', description: 'Production' },
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
        },
      },
      schemas: {
        Error: {
          type: 'object',
          properties: {
            success: { type: 'boolean', example: false },
            message: { type: 'string', example: 'Error message' },
          },
        },
        Success: {
          type: 'object',
          properties: {
            success: { type: 'boolean', example: true },
            message: { type: 'string' },
            data: { type: 'object' },
          },
        },
      },
    },
    security: [{ bearerAuth: [] }],
  },
  apis: ['./routes/*.js', './models/*.js'],
};

module.exports = swaggerJsdoc(options);
