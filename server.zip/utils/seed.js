// utils/seed.js
// Run: node utils/seed.js
require('dotenv').config();

console.log("MONGO_URI =", process.env.MONGO_URI);
const mongoose = require('mongoose');
const User = require('../models/User');
const Medicine = require('../models/Medicine');
const PharmacyProfile = require('../models/PharmacyProfile');
const DoctorProfile = require('../models/DoctorProfile');
const Inventory = require('../models/Inventory');

const MEDICINES = [
  { name: 'Paracetamol 500mg', genericName: 'Acetaminophen', category: 'Analgesic', price: 12.5, mrp: 15, requiresPrescription: false, dosageForm: 'Tablet', manufacturer: 'Cipla' },
  { name: 'Amoxicillin 500mg', genericName: 'Amoxicillin', category: 'Antibiotic', price: 85, mrp: 100, requiresPrescription: true, dosageForm: 'Capsule', manufacturer: 'Sun Pharma' },
  { name: 'Omeprazole 20mg', genericName: 'Omeprazole', category: 'Antacid', price: 45, mrp: 55, requiresPrescription: false, dosageForm: 'Capsule', manufacturer: 'Dr. Reddy\'s' },
  { name: 'Fluconazole 150mg', genericName: 'Fluconazole', category: 'Antifungal', price: 62, mrp: 75, requiresPrescription: true, dosageForm: 'Tablet', manufacturer: 'Lupin' },
  { name: 'Vitamin D3 60000 IU', genericName: 'Cholecalciferol', category: 'Vitamin', price: 120, mrp: 150, requiresPrescription: false, dosageForm: 'Capsule', manufacturer: 'Abbott' },
  { name: 'Amlodipine 5mg', genericName: 'Amlodipine', category: 'Antihypertensive', price: 38, mrp: 45, requiresPrescription: true, dosageForm: 'Tablet', manufacturer: 'Cipla' },
  { name: 'Cetirizine 10mg', genericName: 'Cetirizine HCl', category: 'Antihistamine', price: 22, mrp: 28, requiresPrescription: false, dosageForm: 'Tablet', manufacturer: 'Mankind' },
  { name: 'Metformin 500mg', genericName: 'Metformin HCl', category: 'Antidiabetic', price: 42, mrp: 50, requiresPrescription: true, dosageForm: 'Tablet', manufacturer: 'Sun Pharma' },
  { name: 'Ibuprofen 400mg', genericName: 'Ibuprofen', category: 'Analgesic', price: 30, mrp: 38, requiresPrescription: false, dosageForm: 'Tablet', manufacturer: 'Cipla' },
  { name: 'Azithromycin 500mg', genericName: 'Azithromycin', category: 'Antibiotic', price: 95, mrp: 115, requiresPrescription: true, dosageForm: 'Tablet', manufacturer: 'Pfizer' },
];

async function seed() {
  await mongoose.connect(process.env.MONGO_URI);
  console.log('🔗 Connected to MongoDB');

  // Clear
  await Promise.all([
    User.deleteMany({}), Medicine.deleteMany({}),
    PharmacyProfile.deleteMany({}), DoctorProfile.deleteMany({}),
    Inventory.deleteMany({}),
  ]);
  console.log('🗑️  Cleared existing data');

  // Admin
  const admin = await User.create({ name: 'Super Admin', phone: '+919000000000', role: 'admin', isVerified: true, isActive: true });
  console.log('👤 Admin created:', admin.phone);

  // Medicines
  const medicines = await Medicine.insertMany(MEDICINES);
  console.log(`💊 ${medicines.length} medicines seeded`);

  // Pharmacy users + profiles
  const pharmaData = [
    { phone: '+919111111111', name: 'MedPlus Manager', shop: 'MedPlus Pharmacy', license: 'DL-TG-100001', city: 'Hyderabad', coords: [78.4867, 17.385], tags: ['24/7', 'Home Delivery'] },
    { phone: '+919222222222', name: 'Apollo Manager', shop: 'Apollo Pharmacy', license: 'DL-TG-100002', city: 'Hyderabad', coords: [78.4958, 17.3616], tags: ['Home Delivery'] },
    { phone: '+919333333333', name: 'HealthMart Owner', shop: 'HealthMart', license: 'DL-TG-100003', city: 'Hyderabad', coords: [78.4731, 17.4126], tags: ['Diabetic Care'] },
  ];

  for (const pd of pharmaData) {
    const u = await User.create({ name: pd.name, phone: pd.phone, role: 'pharmacy', isVerified: true });
    const profile = await PharmacyProfile.create({
      owner: u._id, shopName: pd.shop, drugLicense: pd.license,
      address: { city: pd.city, state: 'Telangana' },
      location: { type: 'Point', coordinates: pd.coords },
      status: 'approved', tags: pd.tags,
    });
    u.profileRef = profile._id; u.profileModel = 'PharmacyProfile';
    await u.save();

    // Add inventory for all medicines
    const inv = medicines.map(m => ({
      pharmacy: profile._id, medicine: m._id,
      stock: Math.floor(Math.random() * 200) + 20,
      sellingPrice: m.price,
    }));
    await Inventory.insertMany(inv);
    console.log(`🏥 Pharmacy seeded: ${pd.shop}`);
  }

  // Doctor users + profiles
  const docData = [
    { phone: '+919444444444', name: 'Dr. Priya Sharma', spec: 'General Physician', reg: 'MCI-10001', hospital: 'Apollo Hospital', exp: 12, fee: 300 },
    { phone: '+919555555555', name: 'Dr. Arun Mehta', spec: 'Cardiologist', reg: 'MCI-10002', hospital: 'CARE Hospitals', exp: 18, fee: 500 },
    { phone: '+919666666666', name: 'Dr. Kavita Rao', spec: 'Dermatologist', reg: 'MCI-10003', hospital: 'Yashoda Hospitals', exp: 8, fee: 400 },
  ];

  for (const dd of docData) {
    const u = await User.create({ name: dd.name, phone: dd.phone, role: 'doctor', isVerified: true });
    const profile = await DoctorProfile.create({
      user: u._id, specialization: dd.spec, registrationNo: dd.reg,
      hospital: dd.hospital, experience: dd.exp, consultationFee: dd.fee,
      status: 'approved',
    });
    u.profileRef = profile._id; u.profileModel = 'DoctorProfile';
    await u.save();
    console.log(`🩺 Doctor seeded: ${dd.name}`);
  }

  // Customer
  await User.create({ name: 'Arjun Verma', phone: '+919777777777', role: 'customer', isVerified: true });
  console.log('👤 Customer seeded: +919777777777');

  console.log('\n✅ Seed complete!');
  console.log('─────────────────────────────────────────');
  console.log('Test phones (use OTP = any 6 digits in dev):');
  console.log('  Admin:    +919000000000');
  console.log('  Pharmacy: +919111111111');
  console.log('  Doctor:   +919444444444');
  console.log('  Customer: +919777777777');
  console.log('─────────────────────────────────────────');
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
