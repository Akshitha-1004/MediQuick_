// models/Slot.js
const mongoose = require('mongoose');

/**
 * @swagger
 * components:
 *   schemas:
 *     Slot:
 *       type: object
 *       properties:
 *         _id: { type: string }
 *         doctor: { type: string, description: DoctorProfile ID }
 *         date: { type: string, format: date, example: "2025-06-15" }
 *         time: { type: string, example: "10:00" }
 *         isBooked: { type: boolean }
 *         isActive: { type: boolean }
 */
const slotSchema = new mongoose.Schema(
  {
    doctor: { type: mongoose.Schema.Types.ObjectId, ref: 'DoctorProfile', required: true },
    date: { type: String, required: true }, // "YYYY-MM-DD"
    time: { type: String, required: true }, // "HH:MM"
    isBooked: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
    bookedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

slotSchema.index({ doctor: 1, date: 1 });
slotSchema.index({ doctor: 1, date: 1, time: 1 }, { unique: true });

module.exports = mongoose.model('Slot', slotSchema);
