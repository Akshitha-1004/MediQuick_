// models/Appointment.js
const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

/**
 * @swagger
 * components:
 *   schemas:
 *     Appointment:
 *       type: object
 *       properties:
 *         _id: { type: string }
 *         appointmentId: { type: string, example: APT-AB12CD34 }
 *         patient: { type: string }
 *         doctor: { type: string }
 *         slot: { $ref: '#/components/schemas/Slot' }
 *         reason: { type: string }
 *         status:
 *           type: string
 *           enum: [booked, completed, cancelled, no_show]
 *         consultationFee: { type: number }
 *         notes: { type: string }
 */
const appointmentSchema = new mongoose.Schema(
  {
    appointmentId: {
      type: String,
      unique: true,
      default: () => 'APT-' + uuidv4().slice(0, 8).toUpperCase(),
    },
    patient: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    doctor: { type: mongoose.Schema.Types.ObjectId, ref: 'DoctorProfile', required: true },
    slot: { type: mongoose.Schema.Types.ObjectId, ref: 'Slot', required: true },
    reason: { type: String, required: true },
    status: {
      type: String,
      enum: ['booked', 'completed', 'cancelled', 'no_show'],
      default: 'booked',
    },
    consultationFee: { type: Number, required: true },
    prescription: String, // doctor's prescription notes
    diagnosis: String,
    notes: String,
    cancelReason: String,
  },
  { timestamps: true }
);

module.exports = mongoose.model('Appointment', appointmentSchema);
