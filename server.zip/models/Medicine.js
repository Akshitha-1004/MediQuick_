// models/Medicine.js
const mongoose = require('mongoose');

/**
 * @swagger
 * components:
 *   schemas:
 *     Medicine:
 *       type: object
 *       required: [name, genericName, category, price]
 *       properties:
 *         _id: { type: string }
 *         name: { type: string, example: Paracetamol 500mg }
 *         genericName: { type: string, example: Acetaminophen }
 *         manufacturer: { type: string }
 *         category:
 *           type: string
 *           enum: [Analgesic, Antibiotic, Antacid, Antifungal, Vitamin, Antihypertensive, Antihistamine, Antidiabetic, Other]
 *         price: { type: number, example: 12.5 }
 *         mrp: { type: number }
 *         requiresPrescription: { type: boolean }
 *         description: { type: string }
 *         dosageForm: { type: string, example: Tablet }
 */
const medicineSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, index: true },
    genericName: { type: String, trim: true, index: true },
    manufacturer: { type: String, trim: true },
    category: {
      type: String,
      enum: ['Analgesic', 'Antibiotic', 'Antacid', 'Antifungal', 'Vitamin',
             'Antihypertensive', 'Antihistamine', 'Antidiabetic', 'Other'],
      required: true,
    },
    price: { type: Number, required: true, min: 0 },
    mrp: { type: Number, min: 0 },
    requiresPrescription: { type: Boolean, default: false },
    description: String,
    dosageForm: { type: String, enum: ['Tablet', 'Capsule', 'Syrup', 'Injection', 'Ointment', 'Drops', 'Other'], default: 'Tablet' },
    strength: String, // e.g. "500mg", "10mg/5ml"
    packSize: String, // e.g. "10 tablets", "100ml"
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

medicineSchema.index({ name: 'text', genericName: 'text' });

module.exports = mongoose.model('Medicine', medicineSchema);
