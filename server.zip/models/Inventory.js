// models/Inventory.js
const mongoose = require('mongoose');

/**
 * @swagger
 * components:
 *   schemas:
 *     InventoryItem:
 *       type: object
 *       properties:
 *         _id: { type: string }
 *         pharmacy: { type: string, description: PharmacyProfile ID }
 *         medicine: { $ref: '#/components/schemas/Medicine' }
 *         stock: { type: number, example: 150 }
 *         sellingPrice: { type: number }
 *         expiryDate: { type: string, format: date }
 *         stockStatus:
 *           type: string
 *           enum: [in_stock, low_stock, out_of_stock]
 */
const inventorySchema = new mongoose.Schema(
  {
    pharmacy: { type: mongoose.Schema.Types.ObjectId, ref: 'PharmacyProfile', required: true },
    medicine: { type: mongoose.Schema.Types.ObjectId, ref: 'Medicine', required: true },
    stock: { type: Number, required: true, min: 0, default: 0 },
    sellingPrice: { type: Number, required: true, min: 0 },
    batchNumber: String,
    expiryDate: Date,
    lowStockThreshold: { type: Number, default: 20 },
  },
  { timestamps: true }
);

// Virtual: stock status
inventorySchema.virtual('stockStatus').get(function () {
  if (this.stock === 0) return 'out_of_stock';
  if (this.stock <= this.lowStockThreshold) return 'low_stock';
  return 'in_stock';
});

inventorySchema.set('toJSON', { virtuals: true });

// Unique medicine per pharmacy
inventorySchema.index({ pharmacy: 1, medicine: 1 }, { unique: true });

module.exports = mongoose.model('Inventory', inventorySchema);
