// models/User.js
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

/**
 * @swagger
 * components:
 *   schemas:
 *     User:
 *       type: object
 *       required: [name, phone, role]
 *       properties:
 *         _id:
 *           type: string
 *         name:
 *           type: string
 *           example: Arjun Verma
 *         phone:
 *           type: string
 *           example: "+919876543210"
 *         email:
 *           type: string
 *           example: arjun@example.com
 *         role:
 *           type: string
 *           enum: [customer, pharmacy, doctor, admin]
 *         isActive:
 *           type: boolean
 *         createdAt:
 *           type: string
 *           format: date-time
 */
const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    phone: { type: String, required: true, unique: true, trim: true },
    email: { type: String, trim: true, lowercase: true },
    password: { type: String, select: false },  // hashed, optional (OTP auth)
    role: {
      type: String,
      enum: ['customer', 'pharmacy', 'doctor', 'admin'],
      required: true,
    },
    isActive: { type: Boolean, default: true },
    isVerified: { type: Boolean, default: false },
    // Profile extras stored per-role in separate collections; keep ref here
    profileRef: { type: mongoose.Schema.Types.ObjectId, refPath: 'profileModel' },
    profileModel: { type: String, enum: ['PharmacyProfile', 'DoctorProfile', null] },
    address: {
      street: String,
      city: String,
      state: String,
      pincode: String,
    },
    fcmToken: String, // push notifications
  },
  { timestamps: true }
);

// Hash password if set
userSchema.pre('save', async function (next) {
  if (!this.isModified('password') || !this.password) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

userSchema.methods.matchPassword = async function (entered) {
  return bcrypt.compare(entered, this.password);
};

module.exports = mongoose.model('User', userSchema);
