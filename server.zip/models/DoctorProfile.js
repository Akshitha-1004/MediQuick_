// models/DoctorProfile.js
const mongoose = require('mongoose');

/**
 * @swagger
 * components:
 *   schemas:
 *     DoctorProfile:
 *       type: object
 *       properties:
 *         _id: { type: string }
 *         user: { $ref: '#/components/schemas/User' }
 *         specialization: { type: string, example: General Physician }
 *         registrationNo: { type: string, example: MCI-12345 }
 *         hospital: { type: string }
 *         experience: { type: number }
 *         consultationFee: { type: number }
 *         status: { type: string, enum: [pending, approved, rejected] }
 */
const doctorProfileSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    specialization: { type: String, required: true },
    registrationNo: { type: String, required: true, trim: true },
    hospital: { type: String, required: true },
    experience: { type: Number, default: 0 },
    qualifications: [String],
    consultationFee: { type: Number, default: 300 },
    status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
    rejectionReason: String,
    rating: { type: Number, default: 4.7, min: 0, max: 5 },
    totalRatings: { type: Number, default: 0 },
    about: String,
    languages: [String],
    profilePhoto: String,
  },
  { timestamps: true }
);

module.exports = mongoose.model('DoctorProfile', doctorProfileSchema);
