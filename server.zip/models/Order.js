// models/Order.js
const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

/**
 * @swagger
 * components:
 *   schemas:
 *     Order:
 *       type: object
 *       properties:
 *         _id: { type: string }
 *         orderId: { type: string, example: MQ-2025-ABCD12 }
 *         customer: { type: string }
 *         pharmacy: { type: string }
 *         items:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               medicine: { $ref: '#/components/schemas/Medicine' }
 *               quantity: { type: number }
 *               price: { type: number }
 *         status:
 *           type: string
 *           enum: [pending, accepted, packed, out_for_delivery, delivered, rejected, cancelled]
 *         totalAmount: { type: number }
 *         deliveryAddress: { type: object }
 *         prescriptionUrl: { type: string }
 *         paymentMode: { type: string, enum: [cod, upi, card, wallet] }
 *         paymentStatus: { type: string, enum: [pending, paid, refunded] }
 */
const orderSchema = new mongoose.Schema(
  {
    orderId: {
      type: String,
      unique: true,
      default: () => 'MQ-' + uuidv4().slice(0, 8).toUpperCase(),
    },
    customer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    pharmacy: { type: mongoose.Schema.Types.ObjectId, ref: 'PharmacyProfile', required: true },
    items: [
      {
        medicine: { type: mongoose.Schema.Types.ObjectId, ref: 'Medicine', required: true },
        medicineName: String, // snapshot
        quantity: { type: Number, required: true, min: 1 },
        price: { type: Number, required: true },
      },
    ],
    status: {
      type: String,
      enum: ['pending', 'accepted', 'packed', 'out_for_delivery', 'delivered', 'rejected', 'cancelled'],
      default: 'pending',
    },
    statusHistory: [
      {
        status: String,
        note: String,
        timestamp: { type: Date, default: Date.now },
      },
    ],
    subtotal: { type: Number, required: true },
    deliveryCharge: { type: Number, default: 40 },
    totalAmount: { type: Number, required: true },
    deliveryAddress: {
      street: String,
      city: String,
      pincode: String,
    },
    prescriptionUrl: String,
    paymentMode: { type: String, enum: ['cod', 'upi', 'card', 'wallet'], default: 'cod' },
    paymentStatus: { type: String, enum: ['pending', 'paid', 'refunded'], default: 'pending' },
    rejectionReason: String,
    estimatedDelivery: Date,
  },
  { timestamps: true }
);

module.exports = mongoose.model('Order', orderSchema);
