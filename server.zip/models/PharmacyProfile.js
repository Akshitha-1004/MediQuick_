// models/PharmacyProfile.js
const mongoose = require('mongoose');

/**
 * @swagger
 * components:
 *   schemas:
 *     PharmacyProfile:
 *       type: object
 *       properties:
 *         _id: { type: string }
 *         owner: { $ref: '#/components/schemas/User' }
 *         shopName: { type: string, example: MedPlus Pharmacy }
 *         drugLicense: { type: string, example: DL-MH-123456 }
 *         gstNumber: { type: string }
 *         address: { type: object }
 *         location:
 *           type: object
 *           properties:
 *             type: { type: string, enum: [Point] }
 *             coordinates: { type: array, items: { type: number }, example: [78.4867, 17.3850] }
 *         status:
 *           type: string
 *           enum: [pending, approved, rejected]
 *         rating: { type: number }
 *         openTime: { type: string, example: "09:00" }
 *         closeTime: { type: string, example: "21:00" }
 */
const pharmacyProfileSchema = new mongoose.Schema(
  {
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    shopName: { type: String, required: true, trim: true },
    drugLicense: { type: String, required: true, trim: true },
    gstNumber: { type: String, trim: true },
    address: {
      street: String,
      area: String,
      city: { type: String, default: 'Hyderabad' },
      state: { type: String, default: 'Telangana' },
      pincode: String,
    },
    location: {
      type: { type: String, enum: ['Point'], default: 'Point' },
      coordinates: { type: [Number], default: [78.4867, 17.385] }, // [lng, lat]
    },
    status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
    rejectionReason: String,
    rating: { type: Number, default: 4.5, min: 0, max: 5 },
    totalRatings: { type: Number, default: 0 },
    openTime: { type: String, default: '09:00' },
    closeTime: { type: String, default: '21:00' },
    tags: [String], // e.g. ['24/7', 'Home Delivery']
    homeDelivery: { type: Boolean, default: true },
    deliveryRadius: { type: Number, default: 5 }, // km
  },
  { timestamps: true }
);

pharmacyProfileSchema.index({ location: '2dsphere' });

module.exports = mongoose.model('PharmacyProfile', pharmacyProfileSchema);
